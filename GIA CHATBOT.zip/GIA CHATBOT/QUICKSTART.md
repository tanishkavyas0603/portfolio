# Quick Start Guide - PM-AJAY GIA

## 🚀 Get Started in 5 Minutes

### Step 1: Setup (One-time)
```bash
# Run the automated setup script
setup.bat
```

This will:
- ✅ Create a virtual environment
- ✅ Install all dependencies
- ✅ Create .env file from template

### Step 2: Configure Environment
Edit the `.env` file and add your OpenAI API key:
```
GEMINI_API_KEY=AIzaSyASGJUjuCJ_FkRoyMBm3dRCkYD3G8w6oiQ
```

> **Note**: The chatbot feature requires an OpenAI API key. Get one at https://platform.openai.com/api-keys

### Step 3: Run the Application
```bash
# Start both services with one command
start.bat
```

This will open two terminal windows:
- **ML Service**: http://localhost:8000
- **Frontend**: http://localhost:3000

### Step 4: Access the Application
Open your browser and navigate to:
- **Dashboard**: http://localhost:3000
- **API Documentation**: http://localhost:8000/docs

---

## 📱 Using the Application

### Dashboard
- View overview of schemes, trainings, businesses, and products
- Quick access to featured schemes and recommended training

### Schemes
- Browse all available government schemes
- Click "View & Apply" to see details and apply
- Filter by category, eligibility, and deadline

### Training Programs
- Discover skill development programs
- Enroll in courses that match your profile
- View duration, location, and available seats

### Business
- Register your business profile
- Get recommendations for business support
- Access entrepreneurship schemes

### Products
- List products from your business
- Showcase to potential buyers
- Manage product catalog

### AI Chatbot
- Ask questions about schemes and programs
- Get instant answers powered by OpenAI
- Context-aware assistance

### Document Scanner
- Upload documents (images/PDFs)
- Extract text using OCR
- Process certificates and forms

---

## 🧪 Testing the ML API

### Option 1: Use the Test Script
```bash
python test_api.py
```

### Option 2: Use the Interactive API Docs
1. Navigate to http://localhost:8000/docs
2. Click on any endpoint
3. Click "Try it out"
4. Fill in the request body
5. Click "Execute"

### Option 3: Use cURL
```bash
# Test eligibility prediction
curl -X POST "http://localhost:8000/predict-eligibility" ^
  -H "Content-Type: application/json" ^
  -d "{\"beneficiary\":{\"age\":28,\"gender\":\"Female\",\"caste_category\":\"SC\",\"family_annual_income\":150000,\"education_level\":\"Graduate\",\"skills_possessed\":[\"Tailoring\"],\"employment_status\":\"Self-Employed\",\"district\":\"Delhi\",\"state\":\"Delhi\",\"disability_status\":false,\"household_size\":4,\"land_ownership\":false,\"existing_business\":true},\"scheme_id\":\"test\",\"scheme_criteria\":{\"max_income\":300000,\"categories\":[\"SC\",\"ST\"]}}"
```

---

## 🔧 Manual Setup (Alternative)

If you prefer manual setup:

### 1. Create Virtual Environment
```bash
python -m venv .venv
.venv\Scripts\activate
```

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Configure Environment
```bash
copy .env.example .env
# Edit .env and add your API keys
```

### 4. Run Services
**Terminal 1 - ML Service:**
```bash
uvicorn main:app --reload --port 8000
```

**Terminal 2 - Frontend:**
```bash
reflex run
```

---

## 🎯 Key Features to Try

### 1. Eligibility Prediction
- Navigate to Schemes page
- Click "View & Apply" on any scheme
- See your eligibility score and breakdown

### 2. Skill Recommendations
- The system analyzes your profile
- Recommends skills based on market demand
- Shows income potential and training duration

### 3. Business Ideas
- Get personalized business suggestions
- Based on your investment capacity
- Matched with your existing skills

### 4. AI Assistant
- Go to AI Chatbot page
- Ask: "What schemes are available for SC/ST entrepreneurs?"
- Get intelligent, context-aware responses

### 5. Document Processing
- Go to Document Scanner page
- Upload an image of a certificate
- Extract text automatically

---

## 📊 Sample Data

The application comes with pre-loaded sample data:
- **3 Government Schemes** (Stand-Up India, PM Kaushal Vikas Yojana, National SC-ST Hub)
- **3 Training Programs** (Digital Marketing, Tailoring, Mobile Repair)
- **12 Skills** in the recommendation database
- **7 Income Activities** for business suggestions

---

## 🆘 Common Issues

### Issue: "Module not found"
**Solution**: Make sure you activated the virtual environment
```bash
.venv\Scripts\activate
pip install -r requirements.txt
```

### Issue: "Port already in use"
**Solution**: Change the port numbers
```bash
uvicorn main:app --reload --port 8001
reflex run --frontend-port 3001
```

### Issue: "OpenAI API Error"
**Solution**: 
1. Check your API key in `.env`
2. Verify you have credits in your OpenAI account
3. The chatbot will show an error but other features will work

### Issue: "Tesseract not found"
**Solution**: Install Tesseract OCR
- Download: https://github.com/UB-Mannheim/tesseract/wiki
- Add to PATH or set path in code

---

## 📚 Next Steps

1. **Customize Data**: Edit `app/states/pmajay_state.py` to add your own schemes and programs
2. **Train Models**: Add real data to improve ML predictions
3. **Extend Features**: Add new pages or components in the `app/` directory
4. **Deploy**: Use services like Render, Railway, or AWS for production deployment

---

## 🎓 Learning Resources

- **Reflex Documentation**: https://reflex.dev/docs
- **FastAPI Documentation**: https://fastapi.tiangolo.com
- **Scikit-learn Guide**: https://scikit-learn.org/stable/user_guide.html

---

**Happy Coding! 🚀**
