# PM-AJAY GIA - Project Structure

## 📁 Complete File Tree

```
PM-AJAY-GIA/
│
├── 📄 main.py                      # FastAPI ML Service (Backend)
├── 📄 config.py                    # Reflex Configuration
├── 📄 requirements.txt             # Python Dependencies
├── 📄 .env                         # Environment Variables (SECRET - not in git)
├── 📄 .env.example                 # Environment Template
├── 📄 .gitignore                   # Git Ignore Rules
│
├── 📄 README.md                    # Main Documentation
├── 📄 QUICKSTART.md                # Quick Start Guide
├── 📄 analysis.md                  # Detailed Project Analysis
├── 📄 PROJECT_STRUCTURE.md         # This File
│
├── 📄 setup.bat                    # Windows Setup Script
├── 📄 start.bat                    # Windows Startup Script
├── 📄 test_api.py                  # API Testing Script
│
├── 📂 .venv/                       # Virtual Environment (auto-generated)
│   └── ...
│
├── 📂 app/                         # Reflex Frontend Application
│   │
│   ├── 📄 __init__.py
│   ├── 📄 app.py                   # Main App Entry Point
│   │
│   ├── 📂 components/              # Reusable UI Components
│   │   ├── 📄 __init__.py
│   │   ├── 📄 cards.py             # Card Components (Scheme, Training, Business, Product, Stat)
│   │   ├── 📄 dialogs.py           # Modal Dialogs (Scheme, Training)
│   │   ├── 📄 forms.py             # Form Components (Business, Product)
│   │   ├── 📄 header.py            # Top Header Bar
│   │   └── 📄 sidebar.py           # Navigation Sidebar
│   │
│   ├── 📂 pages/                   # Application Pages
│   │   ├── 📄 __init__.py
│   │   ├── 📄 dashboard.py         # Main Dashboard (Overview)
│   │   ├── 📄 scheme.py            # Schemes Listing Page
│   │   ├── 📄 training.py          # Training Programs Page
│   │   ├── 📄 business.py          # Business Management Page
│   │   ├── 📄 product.py           # Product Marketplace Page
│   │   ├── 📄 chatbot.py           # AI Chatbot Interface
│   │   └── 📄 doc_scan.py          # Document Scanner (OCR)
│   │
│   └── 📂 states/                  # Application State Management
│       ├── 📄 __init__.py
│       ├── 📄 pmajay_state.py      # Main Application State
│       └── 📄 ai_state.py          # AI/OCR State
│
└── 📂 .web/                        # Reflex Build Output (auto-generated)
    └── ...
```

---

## 📊 Component Hierarchy

### **Main Application**
```
app.py (Root)
├── sidebar()
│   ├── sidebar_item("Dashboard")
│   ├── sidebar_item("Schemes")
│   ├── sidebar_item("Training")
│   ├── sidebar_item("Business")
│   ├── sidebar_item("Products")
│   ├── sidebar_item("AI Chatbot")
│   └── sidebar_item("Doc Scanner")
│
├── header()
│
├── render_page() [Dynamic Router]
│   ├── dashboard_page()
│   │   ├── stat_card() × 4
│   │   ├── scheme_card() × 2
│   │   └── training_card() × 2
│   │
│   ├── schemes_page()
│   │   └── scheme_card() × N
│   │
│   ├── training_page()
│   │   └── training_card() × N
│   │
│   ├── business_page()
│   │   ├── business_form()
│   │   └── business_card() × N
│   │
│   ├── products_page()
│   │   ├── product_form()
│   │   └── product_card() × N
│   │
│   ├── chatbot_page()
│   │   └── chat_interface()
│   │
│   └── doc_scan_page()
│       └── ocr_interface()
│
├── scheme_dialog()
└── training_dialog()
```

---

## 🔄 Data Flow Architecture

### **Frontend to Backend Communication**

```
┌─────────────────────────────────────────────────────────────┐
│                    USER INTERFACE (Reflex)                   │
│                                                               │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐    │
│  │Dashboard │  │ Schemes  │  │ Training │  │ Business │    │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘    │
│                                                               │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐                  │
│  │ Products │  │ Chatbot  │  │Doc Scan  │                  │
│  └──────────┘  └──────────┘  └──────────┘                  │
└───────────────────────┬─────────────────────────────────────┘
                        │
                        ▼
┌─────────────────────────────────────────────────────────────┐
│              STATE MANAGEMENT (Reflex State)                 │
│                                                               │
│  ┌────────────────────┐      ┌────────────────────┐         │
│  │  PMAJAYState       │      │    AIState         │         │
│  │  - schemes         │      │  - chat_history    │         │
│  │  - training_progs  │      │  - ocr_results     │         │
│  │  - businesses      │      └────────────────────┘         │
│  │  - products        │                                      │
│  └────────────────────┘                                      │
└───────────────────────┬─────────────────────────────────────┘
                        │
                        ▼
┌─────────────────────────────────────────────────────────────┐
│                  ML API (FastAPI)                            │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  POST /predict-eligibility                           │   │
│  │  ├── EligibilityPredictor                            │   │
│  │  │   ├── Feature Engineering                         │   │
│  │  │   ├── Random Forest Model                         │   │
│  │  │   └── Score Breakdown                             │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  POST /recommend-skills                              │   │
│  │  ├── SkillRecommender                                │   │
│  │  │   ├── Market Demand Analysis                      │   │
│  │  │   └── Profile Matching                            │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  POST /recommend-income-activity                     │   │
│  │  ├── IncomeActivityRecommender                       │   │
│  │  │   ├── Investment Filtering                        │   │
│  │  │   └── ROI Calculation                             │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

---

## 🗂️ File Responsibilities

### **Core Files**

| File | Purpose | Key Functions/Classes |
|------|---------|----------------------|
| `main.py` | ML API Service | `EligibilityPredictor`, `SkillRecommender`, `IncomeActivityRecommender` |
| `config.py` | Reflex Config | `rx.Config` with TailwindCSS plugin |
| `requirements.txt` | Dependencies | All Python packages |
| `.env` | Secrets | API keys, database URLs |

### **App Files**

| File | Purpose | Key Components |
|------|---------|---------------|
| `app/app.py` | Main App | `index()`, `render_page()` |
| `app/states/pmajay_state.py` | Main State | `PMAJAYState` class with all events |
| `app/states/ai_state.py` | AI State | `AIState` for chatbot and OCR |

### **Component Files**

| File | Purpose | Components |
|------|---------|-----------|
| `app/components/cards.py` | Card UI | `scheme_card()`, `training_card()`, `business_card()`, `product_card()`, `stat_card()` |
| `app/components/dialogs.py` | Modals | `scheme_dialog()`, `training_dialog()` |
| `app/components/forms.py` | Forms | `business_form()`, `product_form()` |
| `app/components/header.py` | Header | `header()` |
| `app/components/sidebar.py` | Sidebar | `sidebar()`, `sidebar_item()` |

### **Page Files**

| File | Purpose | Main Function |
|------|---------|--------------|
| `app/pages/dashboard.py` | Overview | `dashboard_page()` |
| `app/pages/scheme.py` | Schemes List | `schemes_page()` |
| `app/pages/training.py` | Training List | `training_page()` |
| `app/pages/business.py` | Business Mgmt | `business_page()` |
| `app/pages/product.py` | Product List | `products_page()` |
| `app/pages/chatbot.py` | AI Chat | `chatbot_page()` |
| `app/pages/doc_scan.py` | OCR | `doc_scan_page()` |

---

## 🔌 API Endpoints Reference

### **ML Service Endpoints** (Port 8000)

| Method | Endpoint | Request Body | Response |
|--------|----------|--------------|----------|
| GET | `/` | None | Status message |
| POST | `/predict-eligibility` | `BeneficiaryProfile`, `scheme_criteria` | Eligibility score, breakdown, recommendations |
| POST | `/recommend-skills` | `BeneficiaryProfile` | Top 5 skill recommendations |
| POST | `/recommend-income-activity` | `BeneficiaryProfile`, `investment_capacity` | Top 3 business ideas |

### **Frontend Routes** (Port 3000)

| Route | Page | Description |
|-------|------|-------------|
| `/` | Dashboard | Main overview |
| `/?page=schemes` | Schemes | Browse schemes |
| `/?page=training` | Training | Browse training |
| `/?page=business` | Business | Manage businesses |
| `/?page=products` | Products | Manage products |
| `/?page=chatbot` | Chatbot | AI assistant |
| `/?page=doc_scan` | Doc Scanner | OCR tool |

---

## 🎨 UI Component Library

### **Cards**
- `stat_card(title, value, icon, color)` - Statistics display
- `scheme_card(scheme)` - Government scheme card
- `training_card(program)` - Training program card
- `business_card(business)` - Business profile card
- `product_card(product)` - Product listing card

### **Dialogs**
- `scheme_dialog()` - Scheme details modal
- `training_dialog()` - Training enrollment modal

### **Forms**
- `business_form()` - Add business form
- `product_form()` - Add product form

### **Navigation**
- `sidebar()` - Main navigation sidebar
- `sidebar_item(name, icon, page)` - Navigation item
- `header()` - Top header bar

---

## 📦 State Variables

### **PMAJAYState**
```python
current_page: Page                          # Active page
is_loading: bool                            # Loading state
beneficiary: Beneficiary | None             # Current user
schemes: list[Scheme]                       # Available schemes
training_programs: list[TrainingProgram]    # Training programs
business_profiles: list[BusinessProfile]    # User businesses
products: list[Product]                     # User products
show_scheme_dialog: bool                    # Dialog visibility
selected_scheme: Scheme | None              # Selected scheme
show_training_dialog: bool                  # Dialog visibility
selected_training: TrainingProgram | None   # Selected program
```

### **AIState**
```python
chat_history: list[Message]                 # Chat messages
is_processing_chat: bool                    # Chat loading
openai_api_key_error: bool                  # API key status
uploaded_image_filename: str                # OCR file name
extracted_text: str                         # OCR result
is_processing_ocr: bool                     # OCR loading
ocr_error: str                              # OCR error message
```

---

## 🚀 Startup Sequence

1. **User runs `start.bat`**
2. **Terminal 1**: FastAPI starts
   - Loads `main.py`
   - Initializes ML models
   - Trains dummy model if needed
   - Starts server on port 8000
3. **Terminal 2**: Reflex starts
   - Loads `config.py`
   - Loads `app/app.py`
   - Compiles frontend
   - Starts dev server on port 3000
4. **User opens browser** → `http://localhost:3000`
5. **Reflex triggers** `on_load` event
6. **State fetches** sample data
7. **Dashboard renders** with data

---

## 📝 Development Workflow

### **Adding a New Page**
1. Create `app/pages/new_page.py`
2. Define `new_page()` function
3. Import in `app/app.py`
4. Add to `render_page()` match statement
5. Add to `Page` type in `pmajay_state.py`
6. Add sidebar item in `sidebar.py`

### **Adding a New Component**
1. Create function in `app/components/`
2. Import in page file
3. Use in page layout

### **Adding a New API Endpoint**
1. Define request/response models in `main.py`
2. Create endpoint function with `@app.post()`
3. Implement business logic
4. Test with `test_api.py`

---

**This structure provides a complete, production-ready foundation for the PM-AJAY GIA system.**
