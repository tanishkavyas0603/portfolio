"""
Logging Configuration for PM-AJAY GIA

Centralized logging setup for the application.
"""

import logging
import sys
from pathlib import Path
from logging.handlers import RotatingFileHandler
from datetime import datetime

# Create logs directory
LOGS_DIR = Path("logs")
LOGS_DIR.mkdir(exist_ok=True)

# Log file path
LOG_FILE = LOGS_DIR / f"pmajay_{datetime.now().strftime('%Y%m%d')}.log"

# Log format
LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


def setup_logger(
    name: str = "pmajay",
    level: int = logging.INFO,
    log_to_file: bool = True,
    log_to_console: bool = True
) -> logging.Logger:
    """
    Setup and configure logger.
    
    Args:
        name: Logger name
        level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_to_file: Whether to log to file
        log_to_console: Whether to log to console
        
    Returns:
        Configured logger instance
    """
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    # Remove existing handlers
    logger.handlers = []
    
    formatter = logging.Formatter(LOG_FORMAT, DATE_FORMAT)
    
    # Console handler
    if log_to_console:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(level)
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)
    
    # File handler with rotation
    if log_to_file:
        file_handler = RotatingFileHandler(
            LOG_FILE,
            maxBytes=10 * 1024 * 1024,  # 10 MB
            backupCount=5
        )
        file_handler.setLevel(level)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    
    return logger


# Create default logger
logger = setup_logger()


# Convenience functions
def log_info(message: str):
    """Log info message"""
    logger.info(message)


def log_error(message: str, exc_info: bool = False):
    """Log error message"""
    logger.error(message, exc_info=exc_info)


def log_warning(message: str):
    """Log warning message"""
    logger.warning(message)


def log_debug(message: str):
    """Log debug message"""
    logger.debug(message)


def log_critical(message: str):
    """Log critical message"""
    logger.critical(message)


# API request/response logging
def log_api_request(endpoint: str, method: str, data: dict = None):
    """Log API request"""
    logger.info(f"API Request: {method} {endpoint}")
    if data:
        logger.debug(f"Request data: {data}")


def log_api_response(endpoint: str, status_code: int, response_time: float):
    """Log API response"""
    logger.info(f"API Response: {endpoint} - Status: {status_code} - Time: {response_time:.2f}s")


# ML model logging
def log_model_prediction(model_name: str, input_data: dict, prediction: dict):
    """Log ML model prediction"""
    logger.info(f"Model Prediction: {model_name}")
    logger.debug(f"Input: {input_data}")
    logger.debug(f"Output: {prediction}")


def log_model_training(model_name: str, accuracy: float, params: dict = None):
    """Log model training"""
    logger.info(f"Model Training: {model_name} - Accuracy: {accuracy:.2%}")
    if params:
        logger.debug(f"Training params: {params}")


# Database logging
def log_db_query(query: str, execution_time: float = None):
    """Log database query"""
    logger.debug(f"DB Query: {query}")
    if execution_time:
        logger.debug(f"Execution time: {execution_time:.3f}s")


def log_db_error(error: str, query: str = None):
    """Log database error"""
    logger.error(f"DB Error: {error}")
    if query:
        logger.debug(f"Failed query: {query}")


# User action logging
def log_user_action(user_id: str, action: str, details: dict = None):
    """Log user action for audit trail"""
    logger.info(f"User Action: {user_id} - {action}")
    if details:
        logger.debug(f"Action details: {details}")


if __name__ == "__main__":
    # Test logging
    logger = setup_logger(level=logging.DEBUG)
    
    log_info("Application started")
    log_debug("Debug message")
    log_warning("Warning message")
    log_error("Error message")
    
    log_api_request("/predict-eligibility", "POST", {"test": "data"})
    log_api_response("/predict-eligibility", 200, 0.45)
    
    log_model_prediction(
        "EligibilityPredictor",
        {"age": 28, "income": 150000},
        {"score": 0.85, "eligible": True}
    )
    
    log_user_action("user123", "apply_for_scheme", {"scheme_id": "stand-up-india"})
    
    print(f"\n✅ Logs written to: {LOG_FILE}")
