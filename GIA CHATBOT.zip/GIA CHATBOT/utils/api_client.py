"""
API Client for Frontend to Backend Communication

This module provides a client to interact with the ML API from the Reflex frontend.
"""

import httpx
import os
from typing import Dict, List, Optional
from dotenv import load_dotenv

load_dotenv()

# ML Service URL
ML_SERVICE_URL = os.getenv("ML_SERVICE_URL", "http://localhost:8000")


class MLAPIClient:
    """Client for ML API endpoints"""
    
    def __init__(self, base_url: str = ML_SERVICE_URL):
        self.base_url = base_url
        self.client = httpx.AsyncClient(timeout=30.0)
    
    async def close(self):
        """Close the HTTP client"""
        await self.client.aclose()
    
    async def predict_eligibility(
        self,
        beneficiary: Dict,
        scheme_criteria: Dict,
        scheme_id: str = "default"
    ) -> Dict:
        """
        Predict scheme eligibility for a beneficiary.
        
        Args:
            beneficiary: Beneficiary profile dict
            scheme_criteria: Scheme eligibility criteria dict
            scheme_id: Scheme identifier
            
        Returns:
            Dict with eligibility_score, is_eligible, confidence, etc.
        """
        try:
            response = await self.client.post(
                f"{self.base_url}/predict-eligibility",
                json={
                    "beneficiary": beneficiary,
                    "scheme_criteria": scheme_criteria,
                    "scheme_id": scheme_id
                }
            )
            response.raise_for_status()
            return response.json()
        except httpx.HTTPError as e:
            print(f"Error predicting eligibility: {e}")
            return {
                "eligibility_score": 0,
                "is_eligible": False,
                "confidence": 0,
                "error": str(e)
            }
    
    async def recommend_skills(self, beneficiary: Dict) -> Dict:
        """
        Get skill recommendations for a beneficiary.
        
        Args:
            beneficiary: Beneficiary profile dict
            
        Returns:
            Dict with recommended_skills list
        """
        try:
            response = await self.client.post(
                f"{self.base_url}/recommend-skills",
                json={"beneficiary": beneficiary}
            )
            response.raise_for_status()
            return response.json()
        except httpx.HTTPError as e:
            print(f"Error recommending skills: {e}")
            return {"recommended_skills": [], "error": str(e)}
    
    async def recommend_income_activity(
        self,
        beneficiary: Dict,
        investment_capacity: float,
        available_time_hours: int
    ) -> Dict:
        """
        Get income-generating activity recommendations.
        
        Args:
            beneficiary: Beneficiary profile dict
            investment_capacity: Available investment amount
            available_time_hours: Available time per day
            
        Returns:
            Dict with recommended_activities list
        """
        try:
            response = await self.client.post(
                f"{self.base_url}/recommend-income-activity",
                json={
                    "beneficiary": beneficiary,
                    "investment_capacity": investment_capacity,
                    "available_time_hours": available_time_hours
                }
            )
            response.raise_for_status()
            return response.json()
        except httpx.HTTPError as e:
            print(f"Error recommending activities: {e}")
            return {"recommended_activities": [], "error": str(e)}
    
    async def health_check(self) -> bool:
        """
        Check if ML API is healthy.
        
        Returns:
            True if API is accessible, False otherwise
        """
        try:
            response = await self.client.get(f"{self.base_url}/")
            return response.status_code == 200
        except:
            return False


# Singleton instance
_ml_client: Optional[MLAPIClient] = None


def get_ml_client() -> MLAPIClient:
    """Get or create ML API client instance"""
    global _ml_client
    if _ml_client is None:
        _ml_client = MLAPIClient()
    return _ml_client


async def close_ml_client():
    """Close ML API client"""
    global _ml_client
    if _ml_client is not None:
        await _ml_client.close()
        _ml_client = None


# Convenience functions
async def predict_eligibility(beneficiary: Dict, scheme_criteria: Dict) -> Dict:
    """Convenience function for eligibility prediction"""
    client = get_ml_client()
    return await client.predict_eligibility(beneficiary, scheme_criteria)


async def recommend_skills(beneficiary: Dict) -> List[Dict]:
    """Convenience function for skill recommendations"""
    client = get_ml_client()
    result = await client.recommend_skills(beneficiary)
    return result.get("recommended_skills", [])


async def recommend_income_activity(
    beneficiary: Dict,
    investment_capacity: float,
    available_time_hours: int = 8
) -> List[Dict]:
    """Convenience function for income activity recommendations"""
    client = get_ml_client()
    result = await client.recommend_income_activity(
        beneficiary,
        investment_capacity,
        available_time_hours
    )
    return result.get("recommended_activities", [])
