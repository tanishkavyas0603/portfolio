"""
Utility functions package
"""

from utils.logger import (
    setup_logger,
    logger,
    log_info,
    log_error,
    log_warning,
    log_debug,
    log_critical,
    log_api_request,
    log_api_response,
    log_model_prediction,
    log_user_action,
)

from utils.api_client import (
    MLAPIClient,
    get_ml_client,
    close_ml_client,
    predict_eligibility,
    recommend_skills,
    recommend_income_activity,
)

__all__ = [
    # Logger
    "setup_logger",
    "logger",
    "log_info",
    "log_error",
    "log_warning",
    "log_debug",
    "log_critical",
    "log_api_request",
    "log_api_response",
    "log_model_prediction",
    "log_user_action",
    # API Client
    "MLAPIClient",
    "get_ml_client",
    "close_ml_client",
    "predict_eligibility",
    "recommend_skills",
    "recommend_income_activity",
]
