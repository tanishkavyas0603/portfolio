@echo off
echo ========================================
echo PM-AJAY GIA - Setup Script
echo ========================================
echo.

REM Check Python installation
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python is not installed or not in PATH
    echo Please install Python 3.10 or higher from python.org
    pause
    exit /b 1
)

echo Python found:
python --version
echo.

REM Create virtual environment
if exist ".venv" (
    echo Virtual environment already exists.
    choice /C YN /M "Do you want to recreate it"
    if errorlevel 2 goto skip_venv
    echo Removing old virtual environment...
    rmdir /s /q .venv
)

echo Creating virtual environment...
python -m venv .venv
if errorlevel 1 (
    echo ERROR: Failed to create virtual environment
    pause
    exit /b 1
)

:skip_venv
echo Activating virtual environment...
call .venv\Scripts\activate.bat

echo.
echo Installing dependencies...
pip install --upgrade pip
pip install -r requirements.txt

if errorlevel 1 (
    echo.
    echo ERROR: Failed to install dependencies
    pause
    exit /b 1
)

echo.
echo ========================================
echo Setup completed successfully!
echo ========================================
echo.

REM Check for .env file
if not exist ".env" (
    echo Creating .env file from template...
    copy .env.example .env
    echo.
    echo IMPORTANT: Please edit .env file and add your OpenAI API key
    echo.
)

echo Next steps:
echo 1. Edit .env file and add your OPENAI_API_KEY
echo 2. Install Tesseract OCR for document scanning:
echo    Download from: https://github.com/UB-Mannheim/tesseract/wiki
echo 3. Run the application using: start.bat
echo.
echo Or run services manually:
echo    Terminal 1: uvicorn main:app --reload --port 8000
echo    Terminal 2: reflex run
echo.

pause
