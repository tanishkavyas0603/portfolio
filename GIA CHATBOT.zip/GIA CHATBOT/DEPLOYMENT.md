# Deployment Guide - PM-AJAY GIA

## 🚀 Deployment Options

### Option 1: Docker Deployment (Recommended)

#### Prerequisites
- Docker installed
- Docker Compose installed

#### Steps

1. **Build and run with Docker Compose**
```bash
# Build images
docker-compose build

# Start services
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

2. **Access the application**
- ML API: http://localhost:8000
- API Docs: http://localhost:8000/docs
- Database: localhost:5432

3. **Initialize database**
```bash
docker-compose exec ml_service python -c "from database import init_db, create_sample_data; init_db(); create_sample_data()"
```

---

### Option 2: Manual Deployment on VPS

#### Prerequisites
- Ubuntu 20.04+ server
- Python 3.10+
- PostgreSQL 15+
- Nginx
- Domain name (optional)

#### Step 1: Server Setup

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install dependencies
sudo apt install -y python3.10 python3.10-venv python3-pip postgresql nginx tesseract-ocr

# Install Node.js (for Reflex)
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs
```

#### Step 2: Database Setup

```bash
# Create PostgreSQL user and database
sudo -u postgres psql
CREATE USER pmajay WITH PASSWORD 'your_secure_password';
CREATE DATABASE pmajay_db OWNER pmajay;
GRANT ALL PRIVILEGES ON DATABASE pmajay_db TO pmajay;
\q
```

#### Step 3: Application Setup

```bash
# Clone/upload your code
cd /var/www
sudo mkdir pmajay && cd pmajay
# Upload your code here

# Create virtual environment
python3.10 -m venv .venv
source .venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Setup environment
cp .env.example .env
nano .env  # Edit with your settings
```

#### Step 4: Configure Environment

Edit `.env`:
```bash
DATABASE_URL=postgresql://pmajay:your_secure_password@localhost:5432/pmajay_db
GEMINI_API_KEY=AIzaSyASGJUjuCJ_FkRoyMBm3dRCkYD3G8w6oiQ
DEBUG=False
```

#### Step 5: Initialize Database

```bash
python -c "from database import init_db, create_sample_data; init_db(); create_sample_data()"
```

#### Step 6: Setup Systemd Services

**ML Service** (`/etc/systemd/system/pmajay-ml.service`):
```ini
[Unit]
Description=PM-AJAY ML Service
After=network.target postgresql.service

[Service]
Type=simple
User=www-data
WorkingDirectory=/var/www/pmajay
Environment="PATH=/var/www/pmajay/.venv/bin"
ExecStart=/var/www/pmajay/.venv/bin/uvicorn main:app --host 0.0.0.0 --port 8000
Restart=always

[Install]
WantedBy=multi-user.target
```

**Reflex Frontend** (`/etc/systemd/system/pmajay-frontend.service`):
```ini
[Unit]
Description=PM-AJAY Frontend
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=/var/www/pmajay
Environment="PATH=/var/www/pmajay/.venv/bin"
ExecStart=/var/www/pmajay/.venv/bin/reflex run --frontend-port 3000 --backend-port 8001
Restart=always

[Install]
WantedBy=multi-user.target
```

Enable and start services:
```bash
sudo systemctl daemon-reload
sudo systemctl enable pmajay-ml pmajay-frontend
sudo systemctl start pmajay-ml pmajay-frontend
sudo systemctl status pmajay-ml pmajay-frontend
```

#### Step 7: Configure Nginx

Create `/etc/nginx/sites-available/pmajay`:
```nginx
server {
    listen 80;
    server_name your-domain.com;

    # Frontend
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }

    # ML API
    location /api/ {
        proxy_pass http://localhost:8000/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Static files
    location /static/ {
        alias /var/www/pmajay/.web/public/;
    }
}
```

Enable site:
```bash
sudo ln -s /etc/nginx/sites-available/pmajay /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

#### Step 8: SSL Certificate (Optional but Recommended)

```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx

# Get certificate
sudo certbot --nginx -d your-domain.com

# Auto-renewal is configured automatically
```

---

### Option 3: Cloud Platform Deployment

#### Render.com

1. **Create New Web Service**
   - Connect your GitHub repository
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `uvicorn main:app --host 0.0.0.0 --port $PORT`

2. **Add Environment Variables**
   - `DATABASE_URL`: Your PostgreSQL connection string
   - `GEMINI_API_KEY`: Your Google Gemini API key

3. **Add PostgreSQL Database**
   - Create new PostgreSQL instance
   - Link to your web service

#### Railway.app

1. **Deploy from GitHub**
   - Connect repository
   - Railway auto-detects Python

2. **Add PostgreSQL**
   - Add PostgreSQL plugin
   - Environment variable auto-configured

3. **Configure Start Command**
   ```
   uvicorn main:app --host 0.0.0.0 --port $PORT
   ```

#### AWS EC2

1. **Launch EC2 Instance**
   - Ubuntu 22.04 LTS
   - t2.medium or larger
   - Configure security groups (ports 80, 443, 22)

2. **Follow VPS deployment steps above**

3. **Configure Auto-scaling (Optional)**
   - Create AMI from configured instance
   - Setup Auto Scaling Group
   - Configure Load Balancer

---

## 🔒 Security Checklist

Before deploying to production:

- [ ] Change default passwords
- [ ] Use strong DATABASE_URL password
- [ ] Enable HTTPS/SSL
- [ ] Configure firewall (UFW/Security Groups)
- [ ] Set DEBUG=False in production
- [ ] Use environment variables for secrets
- [ ] Enable CORS only for your domain
- [ ] Setup regular database backups
- [ ] Configure log rotation
- [ ] Enable rate limiting
- [ ] Setup monitoring and alerts

---

## 📊 Monitoring

### Application Logs
```bash
# View ML service logs
sudo journalctl -u pmajay-ml -f

# View frontend logs
sudo journalctl -u pmajay-frontend -f

# View Nginx logs
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log
```

### Database Monitoring
```bash
# PostgreSQL logs
sudo tail -f /var/log/postgresql/postgresql-15-main.log

# Database size
sudo -u postgres psql -c "SELECT pg_size_pretty(pg_database_size('pmajay_db'));"
```

### System Resources
```bash
# CPU and Memory
htop

# Disk usage
df -h

# Network
netstat -tulpn
```

---

## 🔄 Backup Strategy

### Database Backup
```bash
# Manual backup
pg_dump -U pmajay pmajay_db > backup_$(date +%Y%m%d).sql

# Automated daily backup (crontab)
0 2 * * * pg_dump -U pmajay pmajay_db > /backups/pmajay_$(date +\%Y\%m\%d).sql
```

### Application Backup
```bash
# Backup uploaded files
tar -czf uploads_backup_$(date +%Y%m%d).tar.gz uploaded_files/

# Backup logs
tar -czf logs_backup_$(date +%Y%m%d).tar.gz logs/
```

---

## 🚨 Troubleshooting

### Service won't start
```bash
# Check service status
sudo systemctl status pmajay-ml

# Check logs
sudo journalctl -u pmajay-ml -n 50

# Test manually
cd /var/www/pmajay
source .venv/bin/activate
uvicorn main:app --host 0.0.0.0 --port 8000
```

### Database connection errors
```bash
# Test database connection
psql -U pmajay -d pmajay_db -h localhost

# Check PostgreSQL status
sudo systemctl status postgresql
```

### High memory usage
```bash
# Restart services
sudo systemctl restart pmajay-ml pmajay-frontend

# Check memory
free -h

# Identify memory hogs
ps aux --sort=-%mem | head
```

---

## 📈 Scaling

### Horizontal Scaling
- Deploy multiple ML service instances
- Use load balancer (Nginx/HAProxy)
- Shared PostgreSQL database
- Redis for session management

### Vertical Scaling
- Upgrade server resources
- Optimize database queries
- Enable database connection pooling
- Use caching (Redis)

---

## ✅ Post-Deployment Checklist

- [ ] All services running
- [ ] Database initialized with sample data
- [ ] SSL certificate installed
- [ ] Firewall configured
- [ ] Backups scheduled
- [ ] Monitoring setup
- [ ] Logs rotating
- [ ] API accessible
- [ ] Frontend loading
- [ ] Test all features
- [ ] Performance testing done

---

**Your PM-AJAY GIA application is now deployed! 🎉**
