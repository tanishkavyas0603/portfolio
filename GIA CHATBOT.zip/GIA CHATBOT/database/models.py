"""
Database Models for PM-AJAY GIA

This module defines SQLAlchemy models for production database.
Currently using in-memory data, but this provides the schema for migration.
"""

from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, ForeignKey, Text, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime

Base = declarative_base()


class Beneficiary(Base):
    """Beneficiary/User model"""
    __tablename__ = "beneficiaries"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    aadhaar = Column(String(12), unique=True, nullable=False, index=True)
    phone = Column(String(15))
    email = Column(String(255))
    address = Column(Text)
    district = Column(String(100))
    state = Column(String(100))
    
    # Demographics
    age = Column(Integer)
    gender = Column(String(20))
    caste_category = Column(String(50))
    education_level = Column(String(100))
    
    # Economic
    family_annual_income = Column(Float)
    occupation = Column(String(100))
    employment_status = Column(String(50))
    household_size = Column(Integer)
    land_ownership = Column(Boolean, default=False)
    disability_status = Column(Boolean, default=False)
    
    # Skills
    skills_possessed = Column(JSON)  # List of skills
    
    # Business
    existing_business = Column(Boolean, default=False)
    
    # Metadata
    registration_date = Column(DateTime, default=datetime.utcnow)
    last_updated = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_active = Column(Boolean, default=True)
    
    # Relationships
    applications = relationship("Application", back_populates="beneficiary")
    enrollments = relationship("Enrollment", back_populates="beneficiary")
    business_profiles = relationship("BusinessProfile", back_populates="beneficiary")
    products = relationship("Product", back_populates="beneficiary")


class Scheme(Base):
    """Government Scheme model"""
    __tablename__ = "schemes"
    
    id = Column(Integer, primary_key=True, index=True)
    scheme_name = Column(String(255), nullable=False)
    category = Column(String(100))
    department = Column(String(100))
    
    # Details
    description = Column(Text)
    eligibility = Column(Text)
    benefits = Column(Text)
    eligibility_criteria = Column(JSON)  # Structured criteria
    
    # Dates
    deadline = Column(String(50))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Status
    is_active = Column(Boolean, default=True)
    
    # Relationships
    applications = relationship("Application", back_populates="scheme")


class Application(Base):
    """Scheme Application model"""
    __tablename__ = "applications"
    
    id = Column(Integer, primary_key=True, index=True)
    beneficiary_id = Column(Integer, ForeignKey("beneficiaries.id"), nullable=False)
    scheme_id = Column(Integer, ForeignKey("schemes.id"), nullable=False)
    
    # Application details
    application_date = Column(DateTime, default=datetime.utcnow)
    status = Column(String(50), default="Pending")  # Pending, Approved, Rejected
    eligibility_score = Column(Float)
    
    # Documents
    documents = Column(JSON)  # List of document URLs
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    beneficiary = relationship("Beneficiary", back_populates="applications")
    scheme = relationship("Scheme", back_populates="applications")


class TrainingProgram(Base):
    """Training Program model"""
    __tablename__ = "training_programs"
    
    id = Column(Integer, primary_key=True, index=True)
    program_name = Column(String(255), nullable=False)
    provider = Column(String(255))
    duration = Column(String(100))
    
    # Details
    description = Column(Text)
    location = Column(String(255))
    seats_available = Column(Integer)
    
    # Dates
    start_date = Column(String(50))
    end_date = Column(String(50))
    
    # Status
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    enrollments = relationship("Enrollment", back_populates="program")


class Enrollment(Base):
    """Training Enrollment model"""
    __tablename__ = "enrollments"
    
    id = Column(Integer, primary_key=True, index=True)
    beneficiary_id = Column(Integer, ForeignKey("beneficiaries.id"), nullable=False)
    program_id = Column(Integer, ForeignKey("training_programs.id"), nullable=False)
    
    # Enrollment details
    enrollment_date = Column(DateTime, default=datetime.utcnow)
    completion_status = Column(String(50), default="Enrolled")  # Enrolled, Completed, Dropped
    completion_date = Column(DateTime, nullable=True)
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    beneficiary = relationship("Beneficiary", back_populates="enrollments")
    program = relationship("TrainingProgram", back_populates="enrollments")


class BusinessProfile(Base):
    """Business Profile model"""
    __tablename__ = "business_profiles"
    
    id = Column(Integer, primary_key=True, index=True)
    beneficiary_id = Column(Integer, ForeignKey("beneficiaries.id"), nullable=False)
    
    # Business details
    business_name = Column(String(255), nullable=False)
    business_type = Column(String(100))
    sector = Column(String(100))
    help_needed = Column(Text)
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_active = Column(Boolean, default=True)
    
    # Relationships
    beneficiary = relationship("Beneficiary", back_populates="business_profiles")
    products = relationship("Product", back_populates="business")


class Product(Base):
    """Product model"""
    __tablename__ = "products"
    
    id = Column(Integer, primary_key=True, index=True)
    beneficiary_id = Column(Integer, ForeignKey("beneficiaries.id"), nullable=False)
    business_id = Column(Integer, ForeignKey("business_profiles.id"), nullable=True)
    
    # Product details
    product_name = Column(String(255), nullable=False)
    description = Column(Text)
    price = Column(Float, nullable=False)
    category = Column(String(100))
    
    # Images
    images = Column(JSON)  # List of image URLs
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_active = Column(Boolean, default=True)
    
    # Relationships
    beneficiary = relationship("Beneficiary", back_populates="products")
    business = relationship("BusinessProfile", back_populates="products")


class ChatHistory(Base):
    """Chat History model for AI conversations"""
    __tablename__ = "chat_history"
    
    id = Column(Integer, primary_key=True, index=True)
    beneficiary_id = Column(Integer, ForeignKey("beneficiaries.id"), nullable=True)
    
    # Chat details
    role = Column(String(20), nullable=False)  # user, assistant, system
    content = Column(Text, nullable=False)
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)


class OCRDocument(Base):
    """OCR Document processing history"""
    __tablename__ = "ocr_documents"
    
    id = Column(Integer, primary_key=True, index=True)
    beneficiary_id = Column(Integer, ForeignKey("beneficiaries.id"), nullable=True)
    
    # Document details
    filename = Column(String(255), nullable=False)
    file_path = Column(String(500))
    extracted_text = Column(Text)
    
    # Metadata
    processed_at = Column(DateTime, default=datetime.utcnow)
    processing_time = Column(Float)  # in seconds
