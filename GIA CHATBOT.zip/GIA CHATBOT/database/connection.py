"""
Database Connection and Session Management

This module handles database connections and provides session management.
"""

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import StaticPool
import os
from typing import Generator
from dotenv import load_dotenv

load_dotenv()

# Database URL from environment or default to SQLite
DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "sqlite:///./pmajay.db"
)

# Create engine
if DATABASE_URL.startswith("sqlite"):
    # SQLite specific configuration
    engine = create_engine(
        DATABASE_URL,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
else:
    # PostgreSQL or other databases
    engine = create_engine(
        DATABASE_URL,
        pool_pre_ping=True,
        pool_size=10,
        max_overflow=20,
    )

# Create session factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def get_db() -> Generator[Session, None, None]:
    """
    Dependency function to get database session.
    
    Usage in FastAPI:
        @app.get("/items")
        def read_items(db: Session = Depends(get_db)):
            return db.query(Item).all()
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db():
    """
    Initialize database - create all tables.
    Call this on application startup.
    """
    from database.models import Base
    Base.metadata.create_all(bind=engine)
    print("✅ Database initialized successfully")


def reset_db():
    """
    Reset database - drop and recreate all tables.
    WARNING: This will delete all data!
    """
    from database.models import Base
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    print("✅ Database reset successfully")


# Example usage functions
def create_sample_data():
    """Create sample data for testing"""
    from database.models import Beneficiary, Scheme, TrainingProgram
    from datetime import datetime
    
    db = SessionLocal()
    try:
        # Create sample beneficiary
        beneficiary = Beneficiary(
            name="Sample User",
            aadhaar="123456789012",
            phone="9876543210",
            email="sample@example.com",
            age=28,
            gender="Female",
            caste_category="SC",
            family_annual_income=150000,
            education_level="Graduate",
            skills_possessed=["Tailoring", "Digital Marketing"],
            employment_status="Self-Employed",
            district="Delhi",
            state="Delhi",
            household_size=4,
            existing_business=True,
        )
        db.add(beneficiary)
        
        # Create sample schemes
        schemes = [
            Scheme(
                scheme_name="Stand-Up India",
                category="Entrepreneurship",
                department="MSME",
                description="Support for greenfield enterprises",
                eligibility="SC/ST entrepreneurs",
                benefits="Loan up to ₹10-100 lakhs",
                deadline="2025-12-31",
                eligibility_criteria={
                    "max_income": 300000,
                    "categories": ["SC", "ST"],
                    "min_education": "10th Pass"
                }
            ),
            Scheme(
                scheme_name="PM Kaushal Vikas Yojana",
                category="Skill Development",
                department="Skill Development",
                description="Industry-relevant skill training",
                eligibility="Youth aged 15-45",
                benefits="Free skill training",
                deadline="2025-11-30",
            ),
        ]
        db.add_all(schemes)
        
        # Create sample training programs
        programs = [
            TrainingProgram(
                program_name="Digital Marketing Mastery",
                provider="NSDC",
                duration="3 months",
                description="Comprehensive digital marketing training",
                location="Delhi",
                seats_available=30,
                start_date="2025-02-01",
                end_date="2025-04-30",
            ),
            TrainingProgram(
                program_name="Tailoring & Fashion Design",
                provider="ITI Network",
                duration="6 months",
                description="Professional tailoring certification",
                location="Mumbai",
                seats_available=25,
                start_date="2025-02-15",
                end_date="2025-08-15",
            ),
        ]
        db.add_all(programs)
        
        db.commit()
        print("✅ Sample data created successfully")
        
    except Exception as e:
        db.rollback()
        print(f"❌ Error creating sample data: {e}")
    finally:
        db.close()


if __name__ == "__main__":
    # Initialize database and create sample data
    print("Initializing database...")
    init_db()
    print("\nCreating sample data...")
    create_sample_data()
    print("\n✅ Database setup complete!")
