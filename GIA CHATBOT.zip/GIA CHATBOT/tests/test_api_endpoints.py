"""
Integration Tests for API Endpoints

Run with: pytest tests/test_api_endpoints.py -v
"""

import pytest
import sys
from pathlib import Path
from fastapi.testclient import TestClient

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from main import app


@pytest.fixture
def client():
    """Create test client"""
    return TestClient(app)


@pytest.fixture
def sample_beneficiary():
    """Sample beneficiary data"""
    return {
        "age": 28,
        "gender": "Female",
        "caste_category": "SC",
        "family_annual_income": 150000,
        "education_level": "Graduate",
        "skills_possessed": ["Tailoring", "Digital Marketing"],
        "employment_status": "Self-Employed",
        "district": "Delhi",
        "state": "Delhi",
        "disability_status": False,
        "household_size": 4,
        "land_ownership": False,
        "existing_business": True
    }


@pytest.fixture
def sample_scheme_criteria():
    """Sample scheme criteria"""
    return {
        "max_income": 300000,
        "categories": ["SC", "ST"],
        "min_education": "10th Pass"
    }


class TestRootEndpoint:
    """Test root endpoint"""
    
    def test_root_endpoint(self, client):
        """Test GET /"""
        response = client.get("/")
        assert response.status_code == 200
        assert "status" in response.json()


class TestPredictEligibility:
    """Test eligibility prediction endpoint"""
    
    def test_predict_eligibility_success(self, client, sample_beneficiary, sample_scheme_criteria):
        """Test successful eligibility prediction"""
        response = client.post(
            "/predict-eligibility",
            json={
                "beneficiary": sample_beneficiary,
                "scheme_id": "test-scheme",
                "scheme_criteria": sample_scheme_criteria
            }
        )
        assert response.status_code == 200
        data = response.json()
        assert "eligibility_score" in data
        assert "is_eligible" in data
        assert "confidence" in data
    
    def test_predict_eligibility_missing_fields(self, client):
        """Test with missing required fields"""
        response = client.post(
            "/predict-eligibility",
            json={"beneficiary": {}, "scheme_criteria": {}}
        )
        # Should handle gracefully or return 422
        assert response.status_code in [200, 422]
    
    def test_predict_eligibility_invalid_data(self, client):
        """Test with invalid data types"""
        response = client.post(
            "/predict-eligibility",
            json={
                "beneficiary": {
                    "age": "invalid",  # Should be int
                    "gender": "Female"
                },
                "scheme_criteria": {}
            }
        )
        assert response.status_code == 422  # Validation error


class TestRecommendSkills:
    """Test skill recommendation endpoint"""
    
    def test_recommend_skills_success(self, client, sample_beneficiary):
        """Test successful skill recommendation"""
        response = client.post(
            "/recommend-skills",
            json={"beneficiary": sample_beneficiary}
        )
        assert response.status_code == 200
        data = response.json()
        assert "recommended_skills" in data
        assert isinstance(data["recommended_skills"], list)
    
    def test_recommend_skills_returns_top_skills(self, client, sample_beneficiary):
        """Test that top skills are returned"""
        response = client.post(
            "/recommend-skills",
            json={"beneficiary": sample_beneficiary}
        )
        data = response.json()
        skills = data["recommended_skills"]
        assert len(skills) <= 5  # Default top_n is 5
        
        if len(skills) > 1:
            # Check if sorted by score
            scores = [s["recommendation_score"] for s in skills]
            assert scores == sorted(scores, reverse=True)


class TestRecommendIncomeActivity:
    """Test income activity recommendation endpoint"""
    
    def test_recommend_income_activity_success(self, client, sample_beneficiary):
        """Test successful income activity recommendation"""
        response = client.post(
            "/recommend-income-activity",
            json={
                "beneficiary": sample_beneficiary,
                "investment_capacity": 50000,
                "available_time_hours": 8
            }
        )
        assert response.status_code == 200
        data = response.json()
        assert "recommended_activities" in data
        assert isinstance(data["recommended_activities"], list)
    
    def test_recommend_income_activity_respects_budget(self, client, sample_beneficiary):
        """Test that activities respect investment capacity"""
        investment = 30000
        response = client.post(
            "/recommend-income-activity",
            json={
                "beneficiary": sample_beneficiary,
                "investment_capacity": investment,
                "available_time_hours": 8
            }
        )
        data = response.json()
        activities = data["recommended_activities"]
        
        for activity in activities:
            assert activity["min_investment"] <= investment


class TestAPIPerformance:
    """Test API performance"""
    
    def test_eligibility_prediction_performance(self, client, sample_beneficiary, sample_scheme_criteria):
        """Test that eligibility prediction completes in reasonable time"""
        import time
        
        start = time.time()
        response = client.post(
            "/predict-eligibility",
            json={
                "beneficiary": sample_beneficiary,
                "scheme_id": "test",
                "scheme_criteria": sample_scheme_criteria
            }
        )
        duration = time.time() - start
        
        assert response.status_code == 200
        assert duration < 2.0  # Should complete in less than 2 seconds


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
