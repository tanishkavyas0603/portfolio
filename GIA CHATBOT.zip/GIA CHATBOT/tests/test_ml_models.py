"""
Unit Tests for ML Models

Run with: pytest tests/test_ml_models.py -v
"""

import pytest
import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from main import EligibilityPredictor, SkillRecommender, IncomeActivityRecommender
from pydantic import BaseModel
from typing import List


class MockBeneficiary(BaseModel):
    """Mock beneficiary for testing"""
    age: int = 28
    gender: str = "Female"
    caste_category: str = "SC"
    family_annual_income: float = 150000
    education_level: str = "Graduate"
    skills_possessed: List[str] = ["Tailoring"]
    employment_status: str = "Self-Employed"
    district: str = "Delhi"
    state: str = "Delhi"
    disability_status: bool = False
    household_size: int = 4
    land_ownership: bool = False
    existing_business: bool = True


class TestEligibilityPredictor:
    """Test EligibilityPredictor class"""
    
    @pytest.fixture
    def predictor(self):
        """Create predictor instance"""
        return EligibilityPredictor()
    
    @pytest.fixture
    def beneficiary(self):
        """Create mock beneficiary"""
        return MockBeneficiary()
    
    @pytest.fixture
    def scheme_criteria(self):
        """Create mock scheme criteria"""
        return {
            "max_income": 300000,
            "categories": ["SC", "ST"],
            "min_education": "10th Pass"
        }
    
    def test_predict_eligibility_returns_dict(self, predictor, beneficiary, scheme_criteria):
        """Test that predict_eligibility returns a dictionary"""
        result = predictor.predict_eligibility(beneficiary, scheme_criteria)
        assert isinstance(result, dict)
    
    def test_predict_eligibility_has_required_keys(self, predictor, beneficiary, scheme_criteria):
        """Test that result has all required keys"""
        result = predictor.predict_eligibility(beneficiary, scheme_criteria)
        assert "eligibility_score" in result
        assert "is_eligible" in result
        assert "confidence" in result
        assert "score_breakdown" in result
        assert "recommendations" in result
    
    def test_eligibility_score_in_range(self, predictor, beneficiary, scheme_criteria):
        """Test that eligibility score is between 0 and 100"""
        result = predictor.predict_eligibility(beneficiary, scheme_criteria)
        assert 0 <= result["eligibility_score"] <= 100
    
    def test_confidence_in_range(self, predictor, beneficiary, scheme_criteria):
        """Test that confidence is between 0 and 1"""
        result = predictor.predict_eligibility(beneficiary, scheme_criteria)
        assert 0 <= result["confidence"] <= 1
    
    def test_is_eligible_is_boolean(self, predictor, beneficiary, scheme_criteria):
        """Test that is_eligible is a boolean"""
        result = predictor.predict_eligibility(beneficiary, scheme_criteria)
        assert isinstance(result["is_eligible"], bool)
    
    def test_recommendations_is_list(self, predictor, beneficiary, scheme_criteria):
        """Test that recommendations is a list"""
        result = predictor.predict_eligibility(beneficiary, scheme_criteria)
        assert isinstance(result["recommendations"], list)


class TestSkillRecommender:
    """Test SkillRecommender class"""
    
    @pytest.fixture
    def recommender(self):
        """Create recommender instance"""
        rec = SkillRecommender()
        rec.build_skill_database()
        return rec
    
    @pytest.fixture
    def beneficiary(self):
        """Create mock beneficiary"""
        return MockBeneficiary()
    
    def test_recommend_skills_returns_list(self, recommender, beneficiary):
        """Test that recommend_skills returns a list"""
        result = recommender.recommend_skills(beneficiary)
        assert isinstance(result, list)
    
    def test_recommend_skills_returns_top_n(self, recommender, beneficiary):
        """Test that recommend_skills returns correct number of results"""
        result = recommender.recommend_skills(beneficiary, top_n=3)
        assert len(result) <= 3
    
    def test_skill_has_required_fields(self, recommender, beneficiary):
        """Test that each skill has required fields"""
        result = recommender.recommend_skills(beneficiary, top_n=1)
        if result:
            skill = result[0]
            assert "skill" in skill
            assert "recommendation_score" in skill
            assert "market_demand" in skill
            assert "average_income" in skill
            assert "growth_rate" in skill
    
    def test_skills_sorted_by_score(self, recommender, beneficiary):
        """Test that skills are sorted by recommendation score"""
        result = recommender.recommend_skills(beneficiary, top_n=5)
        scores = [s["recommendation_score"] for s in result]
        assert scores == sorted(scores, reverse=True)


class TestIncomeActivityRecommender:
    """Test IncomeActivityRecommender class"""
    
    @pytest.fixture
    def recommender(self):
        """Create recommender instance"""
        rec = IncomeActivityRecommender()
        rec.build_activity_database()
        return rec
    
    @pytest.fixture
    def request_data(self):
        """Create mock request"""
        from main import IncomeActivityRequest
        return IncomeActivityRequest(
            beneficiary=MockBeneficiary(),
            investment_capacity=50000,
            available_time_hours=8
        )
    
    def test_recommend_activities_returns_list(self, recommender, request_data):
        """Test that recommend_activities returns a list"""
        result = recommender.recommend_activities(request_data)
        assert isinstance(result, list)
    
    def test_activities_within_budget(self, recommender, request_data):
        """Test that recommended activities are within investment capacity"""
        result = recommender.recommend_activities(request_data)
        for activity in result:
            assert activity["min_investment"] <= request_data.investment_capacity
    
    def test_activities_have_required_fields(self, recommender, request_data):
        """Test that each activity has required fields"""
        result = recommender.recommend_activities(request_data, top_n=1)
        if result:
            activity = result[0]
            assert "activity" in activity
            assert "min_investment" in activity
            assert "potential_income" in activity
            assert "required_skills" in activity
            assert "recommendation_score" in activity


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
