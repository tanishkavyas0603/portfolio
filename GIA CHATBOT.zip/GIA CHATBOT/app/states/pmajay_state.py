import reflex as rx
from typing import TypedDict, Literal
import asyncio
from datetime import date


class Beneficiary(TypedDict):
    id: int
    name: str
    caste_certificate_no: str | None
    aadhaar: str
    phone: str | None
    email: str | None
    address: str | None
    district: str | None
    state: str | None
    income: float | None
    occupation: str | None
    family_size: int | None
    registration_date: str


class Scheme(TypedDict):
    id: int
    scheme_name: str
    category: str
    eligibility: str
    benefits: str
    deadline: str
    department: str
    description: str
    is_active: bool


class TrainingProgram(TypedDict):
    id: int
    program_name: str
    duration: str
    provider: str
    seats: int
    location: str
    start_date: str
    end_date: str
    description: str
    is_active: bool


class BusinessProfile(TypedDict):
    id: int
    beneficiary_id: int
    business_name: str
    business_type: str
    sector: str
    help_needed: str | None


class Product(TypedDict):
    id: int
    beneficiary_id: int
    product_name: str
    description: str | None
    price: float
    category: str
    images: str | None


Page = Literal[
    "dashboard", "schemes", "training", "business", "products", "chatbot", "doc_scan"
]


class PMAJAYState(rx.State):
    current_page: Page = "dashboard"
    is_loading: bool = True
    beneficiary: Beneficiary | None = None
    schemes: list[Scheme] = []
    training_programs: list[TrainingProgram] = []
    business_profiles: list[BusinessProfile] = []
    products: list[Product] = []
    show_scheme_dialog: bool = False
    selected_scheme: Scheme | None = None
    show_training_dialog: bool = False
    selected_training: TrainingProgram | None = None
    show_business_form: bool = False
    show_product_form: bool = False

    @rx.event
    async def on_load(self):
        self.beneficiary = Beneficiary(
            id=1,
            name="Test User",
            aadhaar="123456789012",
            registration_date=str(date.today()),
        )
        yield PMAJAYState.fetch_all_data()

    @rx.event(background=True)
    async def fetch_all_data(self):
        async with self:
            self.is_loading = True
        await asyncio.sleep(1)
        async with self:
            self.schemes = [
                Scheme(
                    id=1,
                    scheme_name="Stand-Up India",
                    category="Entrepreneurship",
                    eligibility="SC/ST entrepreneurs",
                    benefits="Loan up to ₹10-100 lakhs",
                    deadline="2025-12-31",
                    department="MSME",
                    description="Support for greenfield enterprises",
                    is_active=True,
                ),
                Scheme(
                    id=2,
                    scheme_name="PM Kaushal Vikas Yojana",
                    category="Skill Development",
                    eligibility="Youth aged 15-45",
                    benefits="Free skill training",
                    deadline="2025-11-30",
                    department="Skill Development",
                    description="Industry-relevant skill training",
                    is_active=True,
                ),
                Scheme(
                    id=3,
                    scheme_name="National SC-ST Hub",
                    category="Business Support",
                    eligibility="SC/ST entrepreneurs",
                    benefits="Marketing support",
                    deadline="2025-12-31",
                    department="MSME",
                    description="Facilitates participation in government procurement",
                    is_active=True,
                ),
            ]
            self.training_programs = [
                TrainingProgram(
                    id=1,
                    program_name="Digital Marketing Mastery",
                    duration="3 months",
                    provider="NSDC",
                    seats=30,
                    location="Delhi",
                    start_date="2025-02-01",
                    end_date="2025-04-30",
                    description="Comprehensive digital marketing training",
                    is_active=True,
                ),
                TrainingProgram(
                    id=2,
                    program_name="Tailoring & Fashion Design",
                    duration="6 months",
                    provider="ITI Network",
                    seats=25,
                    location="Mumbai",
                    start_date="2025-02-15",
                    end_date="2025-08-15",
                    description="Professional tailoring certification",
                    is_active=True,
                ),
                TrainingProgram(
                    id=3,
                    program_name="Mobile Repair Technician",
                    duration="2 months",
                    provider="Skill India",
                    seats=20,
                    location="Bangalore",
                    start_date="2025-03-01",
                    end_date="2025-04-30",
                    description="Smartphone repair training",
                    is_active=True,
                ),
            ]
            self.is_loading = False

    @rx.event
    def set_current_page(self, page: Page):
        self.current_page = page

    @rx.event
    def open_scheme_dialog(self, scheme: Scheme):
        self.selected_scheme = scheme
        self.show_scheme_dialog = True

    @rx.event
    def close_scheme_dialog(self):
        self.show_scheme_dialog = False
        self.selected_scheme = None

    @rx.event
    def apply_for_scheme(self):
        self.close_scheme_dialog()
        yield rx.toast.success(
            f"Applied for {self.selected_scheme['scheme_name']}!", duration=3000
        )

    @rx.event
    def open_training_dialog(self, program: TrainingProgram):
        self.selected_training = program
        self.show_training_dialog = True

    @rx.event
    def close_training_dialog(self):
        self.show_training_dialog = False
        self.selected_training = None

    @rx.event
    def apply_for_training(self):
        self.close_training_dialog()
        yield rx.toast.success(
            f"Enrolled in {self.selected_training['program_name']}!", duration=3000
        )

    @rx.event
    def toggle_business_form(self):
        self.show_business_form = not self.show_business_form

    @rx.event
    def add_business(self, form_data: dict):
        new_id = len(self.business_profiles) + 1
        new_business = BusinessProfile(
            id=new_id,
            beneficiary_id=self.beneficiary["id"],
            business_name=form_data["business_name"],
            business_type=form_data["business_type"],
            sector=form_data["sector"],
            help_needed=form_data["help_needed"],
        )
        self.business_profiles.append(new_business)
        self.toggle_business_form()
        yield rx.toast.info("Business profile added!", duration=3000)

    @rx.event
    def toggle_product_form(self):
        self.show_product_form = not self.show_product_form

    @rx.event
    def add_product(self, form_data: dict):
        new_id = len(self.products) + 1
        new_product = Product(
            id=new_id,
            beneficiary_id=self.beneficiary["id"],
            product_name=form_data["product_name"],
            description=form_data["description"],
            price=float(form_data["price"]),
            category=form_data["category"],
            images=None,
        )
        self.products.append(new_product)
        self.toggle_product_form()
        yield rx.toast.info("Product added!", duration=3000)