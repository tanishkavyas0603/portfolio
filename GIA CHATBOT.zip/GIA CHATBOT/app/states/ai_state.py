import reflex as rx
import os
import asyncio
import logging
from typing import TypedDict

try:
    import google.generativeai as genai
except ImportError as e:
    logging.exception(e)
    genai = None
try:
    import pytesseract
    from PIL import Image
    import cv2
    import numpy as np
except ImportError as e:
    logging.exception(e)
    pytesseract = None
    Image = None
    cv2 = None
    np = None


class Message(TypedDict):
    role: str
    content: str


class AIState(rx.State):
    """Handles AI chatbot and OCR functionality."""

    chat_history: list[Message] = [
        {
            "role": "system",
            "content": "You are a helpful assistant for the PM-AJAY GIA scheme.",
        }
    ]
    is_processing_chat: bool = False
    gemini_api_key_error: bool = not os.getenv("GEMINI_API_KEY")
    uploaded_image_filename: str = ""
    extracted_text: str = ""
    is_processing_ocr: bool = False
    ocr_error: str = ""

    @rx.var
    def get_chat_history(self) -> list[Message]:
        return self.chat_history[1:]

    @rx.event
    async def answer_question(self, form_data: dict):
        question = form_data.get("question", "").strip()
        if not question:
            return
        if self.gemini_api_key_error:
            yield rx.toast.error(
                "Gemini API key is not set. Please add it in your environment."
            )
            return
        self.is_processing_chat = True
        self.chat_history.append({"role": "user", "content": question})
        yield
        try:
            # Configure Gemini
            genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
            model = genai.GenerativeModel('gemini-pro')
            
            # Build conversation history for Gemini
            conversation_text = "\n".join([
                f"{msg['role']}: {msg['content']}" 
                for msg in self.chat_history[1:]  # Skip system message
            ])
            
            # Generate response
            response = await asyncio.to_thread(
                model.generate_content,
                conversation_text
            )
            
            assistant_message = response.text
            self.chat_history.append(
                {"role": "assistant", "content": assistant_message}
            )
        except Exception as e:
            logging.exception(e)
            self.chat_history.append({"role": "assistant", "content": f"Error: {e}"})
        finally:
            self.is_processing_chat = False
            yield

    @rx.event
    async def handle_ocr_upload(self, files: list[rx.UploadFile]):
        if not files:
            return
        self.is_processing_ocr = True
        self.extracted_text = ""
        self.ocr_error = ""
        upload_data = await files[0].read()
        upload_dir = rx.get_upload_dir()
        upload_dir.mkdir(parents=True, exist_ok=True)
        file_path = upload_dir / files[0].name
        with file_path.open("wb") as f:
            f.write(upload_data)
        self.uploaded_image_filename = files[0].name
        yield
        try:
            if pytesseract is None:
                raise ImportError("OCR libraries not installed.")
            image = Image.open(file_path)
            open_cv_image = np.array(image)
            gray_image = cv2.cvtColor(open_cv_image, cv2.COLOR_BGR2GRAY)
            _, binary_image = cv2.threshold(gray_image, 150, 255, cv2.THRESH_BINARY)
            text = await asyncio.to_thread(pytesseract.image_to_string, binary_image)
            self.extracted_text = (
                text if text.strip() else "No text found in the document."
            )
        except Exception as e:
            logging.exception(e)
            self.ocr_error = f"An error occurred during OCR processing: {e}"
        finally:
            self.is_processing_ocr = False
            yield

    @rx.event
    def clear_ocr_state(self):
        self.uploaded_image_filename = ""
        self.extracted_text = ""
        self.ocr_error = ""