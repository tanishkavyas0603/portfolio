import reflex as rx
from app.states.pmajay_state import PMAJAYState
from app.states.ai_state import AIState
from app.components.sidebar import sidebar
from app.components.header import header
from app.components.dialogs import scheme_dialog, training_dialog
from app.pages.dashboard import dashboard_page
from app.pages.schemes import schemes_page
from app.pages.training import training_page
from app.pages.business import business_page
from app.pages.product import products_page
from app.pages.chatbot import chatbot_page
from app.pages.doc_scan import doc_scan_page


def render_page() -> rx.Component:
    return rx.match(
        PMAJAYState.current_page,
        ("dashboard", dashboard_page()),
        ("schemes", schemes_page()),
        ("training", training_page()),
        ("business", business_page()),
        ("products", products_page()),
        ("chatbot", chatbot_page()),
        ("doc_scan", doc_scan_page()),
        dashboard_page(),
    )


def index() -> rx.Component:
    return rx.el.div(
        sidebar(),
        rx.el.main(
            header(),
            rx.cond(
                PMAJAYState.is_loading,
                rx.el.div(
                    rx.spinner(size="3"),
                    class_name="flex items-center justify-center h-[calc(100vh-80px)]",
                ),
                render_page(),
            ),
            class_name="flex-1 flex flex-col bg-gray-50",
        ),
        scheme_dialog(),
        training_dialog(),
        class_name="flex min-h-screen font-['Poppins']",
    )


app = rx.App(
    theme=rx.theme(appearance="light"),
    head_components=[
        rx.el.link(rel="preconnect", href="https://fonts.googleapis.com"),
        rx.el.link(rel="preconnect", href="https://fonts.gstatic.com", crossorigin=""),
        rx.el.link(
            href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap",
            rel="stylesheet",
        ),
    ],
)
app.add_page(index, on_load=PMAJAYState.on_load)