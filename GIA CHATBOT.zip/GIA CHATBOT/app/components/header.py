import reflex as rx
from app.states.pmajay_state import PMAJAYState


def header() -> rx.Component:
    return rx.el.header(
        rx.el.div(
            rx.el.h2(
                PMAJAYState.current_page.capitalize(),
                class_name="text-2xl font-bold text-gray-800",
            ),
            class_name="flex items-center gap-4",
        ),
        rx.el.div(
            rx.el.button(
                rx.icon("bell", size=20),
                class_name="p-2 rounded-full hover:bg-gray-100 text-gray-600",
            ),
            class_name="flex items-center gap-2",
        ),
        class_name="flex items-center justify-between p-4 border-b border-gray-200 bg-white",
    )