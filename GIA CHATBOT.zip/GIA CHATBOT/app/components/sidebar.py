import reflex as rx
from app.states.pmajay_state import PMAJAYState, Page


def sidebar_item(name: str, icon: str, page: Page) -> rx.Component:
    is_active = PMAJAYState.current_page == page
    return rx.el.a(
        rx.el.div(
            rx.icon(icon, size=20, class_name="transition-colors duration-150"),
            rx.el.span(
                name, class_name="text-sm font-medium transition-colors duration-150"
            ),
            class_name=rx.cond(
                is_active,
                "flex items-center gap-3 px-3 py-2 rounded-lg bg-blue-50 text-blue-600",
                "flex items-center gap-3 px-3 py-2 rounded-lg text-gray-500 hover:bg-gray-100 hover:text-gray-900",
            ),
            on_click=lambda: PMAJAYState.set_current_page(page),
            href="#",
        )
    )


def sidebar() -> rx.Component:
    return rx.el.aside(
        rx.el.div(
            rx.el.div(
                rx.icon("layers", size=28, class_name="text-blue-600"),
                rx.el.h1("PM-AJAY GIA", class_name="text-xl font-bold text-gray-800"),
                class_name="flex items-center gap-3 p-4 border-b border-gray-200",
            ),
            rx.el.nav(
                sidebar_item("Dashboard", "layout-dashboard", "dashboard"),
                sidebar_item("Schemes", "award", "schemes"),
                sidebar_item("Training", "school", "training"),
                sidebar_item("Business", "briefcase", "business"),
                sidebar_item("Products", "package", "products"),
                rx.el.div(class_name="my-2 border-t border-gray-200"),
                sidebar_item("AI Chatbot", "bot", "chatbot"),
                sidebar_item("Doc Scanner", "scan-text", "doc_scan"),
                class_name="flex flex-col gap-1 p-4",
            ),
            class_name="flex-1",
        ),
        rx.el.div(
            rx.cond(
                PMAJAYState.beneficiary,
                rx.el.div(
                    rx.image(
                        src=f"https://api.dicebear.com/9.x/initials/svg?seed={PMAJAYState.beneficiary['name']}",
                        class_name="size-10 rounded-full",
                    ),
                    rx.el.div(
                        rx.el.p(
                            PMAJAYState.beneficiary["name"],
                            class_name="text-sm font-semibold text-gray-900",
                        ),
                        rx.el.p(
                            f"Aadhaar: ...{PMAJAYState.beneficiary['aadhaar'][-4:]}",
                            class_name="text-xs text-gray-500",
                        ),
                        class_name="flex-1",
                    ),
                    rx.icon(
                        "log-out",
                        size=18,
                        class_name="text-gray-500 hover:text-red-600 cursor-pointer",
                    ),
                    class_name="flex items-center gap-3",
                ),
            ),
            class_name="p-4 border-t border-gray-200",
        ),
        class_name="hidden md:flex flex-col w-64 bg-white border-r border-gray-200",
    )