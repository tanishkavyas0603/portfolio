import reflex as rx
from app.states.pmajay_state import PMAJAYState


def business_form() -> rx.Component:
    return rx.el.form(
        rx.el.div(
            rx.el.h3("Add Business Profile", class_name="text-lg font-semibold mb-4"),
            rx.el.input(
                placeholder="Business Name",
                name="business_name",
                class_name="w-full p-2 border rounded-md mb-2",
            ),
            rx.el.input(
                placeholder="Business Type (e.g., Sole Proprietorship)",
                name="business_type",
                class_name="w-full p-2 border rounded-md mb-2",
            ),
            rx.el.input(
                placeholder="Sector (e.g., Retail, Services)",
                name="sector",
                class_name="w-full p-2 border rounded-md mb-2",
            ),
            rx.el.textarea(
                placeholder="What help do you need?",
                name="help_needed",
                class_name="w-full p-2 border rounded-md mb-4",
            ),
            rx.el.div(
                rx.el.button(
                    "Cancel",
                    type="button",
                    on_click=PMAJAYState.toggle_business_form,
                    class_name="px-4 py-2 bg-gray-200 rounded-lg",
                ),
                rx.el.button(
                    "Save Business",
                    type="submit",
                    class_name="px-4 py-2 bg-purple-500 text-white rounded-lg",
                ),
                class_name="flex justify-end gap-4",
            ),
        ),
        on_submit=PMAJAYState.add_business,
        reset_on_submit=True,
        class_name="bg-white p-6 rounded-xl border",
    )


def product_form() -> rx.Component:
    return rx.el.form(
        rx.el.div(
            rx.el.h3("Add New Product", class_name="text-lg font-semibold mb-4"),
            rx.el.input(
                placeholder="Product Name",
                name="product_name",
                class_name="w-full p-2 border rounded-md mb-2",
            ),
            rx.el.input(
                placeholder="Category",
                name="category",
                class_name="w-full p-2 border rounded-md mb-2",
            ),
            rx.el.input(
                placeholder="Price",
                name="price",
                type="number",
                class_name="w-full p-2 border rounded-md mb-2",
            ),
            rx.el.textarea(
                placeholder="Product Description",
                name="description",
                class_name="w-full p-2 border rounded-md mb-4",
            ),
            rx.el.div(
                rx.el.button(
                    "Cancel",
                    type="button",
                    on_click=PMAJAYState.toggle_product_form,
                    class_name="px-4 py-2 bg-gray-200 rounded-lg",
                ),
                rx.el.button(
                    "Add Product",
                    type="submit",
                    class_name="px-4 py-2 bg-orange-500 text-white rounded-lg",
                ),
                class_name="flex justify-end gap-4",
            ),
        ),
        on_submit=PMAJAYState.add_product,
        reset_on_submit=True,
        class_name="bg-white p-6 rounded-xl border",
    )