import reflex as rx
from app.states.pmajay_state import PMAJAYState


def scheme_dialog() -> rx.Component:
    return rx.radix.primitives.dialog.root(
        rx.radix.primitives.dialog.trigger(rx.fragment()),
        rx.radix.primitives.dialog.content(
            rx.cond(
                PMAJAYState.selected_scheme,
                rx.el.div(
                    rx.radix.primitives.dialog.title(
                        PMAJAYState.selected_scheme["scheme_name"],
                        class_name="text-2xl font-bold text-gray-800 mb-2",
                    ),
                    rx.radix.primitives.dialog.description(
                        PMAJAYState.selected_scheme["description"],
                        class_name="text-gray-600 mb-4",
                    ),
                    rx.el.div(
                        rx.el.div(
                            rx.el.strong("Category: "),
                            PMAJAYState.selected_scheme["category"],
                        ),
                        rx.el.div(
                            rx.el.strong("Department: "),
                            PMAJAYState.selected_scheme["department"],
                        ),
                        rx.el.div(
                            rx.el.strong("Eligibility: "),
                            PMAJAYState.selected_scheme["eligibility"],
                        ),
                        rx.el.div(
                            rx.el.strong("Benefits: "),
                            PMAJAYState.selected_scheme["benefits"],
                            class_name="text-green-600 font-semibold",
                        ),
                        rx.el.div(
                            rx.el.strong("Deadline: "),
                            PMAJAYState.selected_scheme["deadline"],
                            class_name="text-red-600 font-semibold",
                        ),
                        class_name="space-y-2 text-sm",
                    ),
                    rx.el.div(
                        rx.el.button(
                            "Cancel",
                            on_click=PMAJAYState.close_scheme_dialog,
                            class_name="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors font-medium",
                        ),
                        rx.el.button(
                            "Apply Now",
                            on_click=PMAJAYState.apply_for_scheme,
                            class_name="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors font-medium",
                        ),
                        class_name="flex justify-end gap-4 mt-6",
                    ),
                ),
            ),
            class_name="bg-white p-6 rounded-xl shadow-lg max-w-lg w-full",
        ),
        open=PMAJAYState.show_scheme_dialog,
        on_open_change=PMAJAYState.close_scheme_dialog,
    )


def training_dialog() -> rx.Component:
    return rx.radix.primitives.dialog.root(
        rx.radix.primitives.dialog.trigger(rx.fragment()),
        rx.radix.primitives.dialog.content(
            rx.cond(
                PMAJAYState.selected_training,
                rx.el.div(
                    rx.radix.primitives.dialog.title(
                        PMAJAYState.selected_training["program_name"],
                        class_name="text-2xl font-bold text-gray-800 mb-2",
                    ),
                    rx.radix.primitives.dialog.description(
                        PMAJAYState.selected_training["description"],
                        class_name="text-gray-600 mb-4",
                    ),
                    rx.el.div(
                        rx.el.div(
                            rx.el.strong("Provider: "),
                            PMAJAYState.selected_training["provider"],
                        ),
                        rx.el.div(
                            rx.el.strong("Duration: "),
                            PMAJAYState.selected_training["duration"],
                        ),
                        rx.el.div(
                            rx.el.strong("Location: "),
                            PMAJAYState.selected_training["location"],
                        ),
                        rx.el.div(
                            rx.el.strong("Seats Available: "),
                            PMAJAYState.selected_training["seats"],
                        ),
                        rx.el.div(
                            rx.el.strong("Starts on: "),
                            PMAJAYState.selected_training["start_date"],
                        ),
                        class_name="space-y-2 text-sm",
                    ),
                    rx.el.div(
                        rx.el.button(
                            "Cancel",
                            on_click=PMAJAYState.close_training_dialog,
                            class_name="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors font-medium",
                        ),
                        rx.el.button(
                            "Enroll",
                            on_click=PMAJAYState.apply_for_training,
                            class_name="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors font-medium",
                        ),
                        class_name="flex justify-end gap-4 mt-6",
                    ),
                ),
            ),
            class_name="bg-white p-6 rounded-xl shadow-lg max-w-lg w-full",
        ),
        open=PMAJAYState.show_training_dialog,
        on_open_change=PMAJAYState.close_training_dialog,
    )