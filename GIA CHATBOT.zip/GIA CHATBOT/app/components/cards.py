import reflex as rx
from app.states.pmajay_state import (
    Scheme,
    TrainingProgram,
    BusinessProfile,
    Product,
    PMAJAYState,
)


def scheme_card(scheme: Scheme) -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.el.div(
                rx.icon("award", class_name="text-blue-500"),
                rx.el.h3(
                    scheme["scheme_name"], class_name="font-semibold text-gray-800"
                ),
                class_name="flex items-center gap-3",
            ),
            rx.el.span(
                scheme["category"],
                class_name="px-2 py-1 text-xs font-medium rounded-full bg-blue-50 text-blue-600",
            ),
            class_name="flex items-center justify-between",
        ),
        rx.el.p(scheme["description"], class_name="text-sm text-gray-600 mt-2"),
        rx.el.div(
            rx.el.div(
                rx.el.p("Benefits", class_name="text-xs text-gray-500"),
                rx.el.p(
                    scheme["benefits"], class_name="text-sm font-medium text-gray-800"
                ),
                class_name="flex-1",
            ),
            rx.el.div(
                rx.el.p("Deadline", class_name="text-xs text-gray-500"),
                rx.el.p(
                    scheme["deadline"], class_name="text-sm font-medium text-red-600"
                ),
                class_name="flex-1",
            ),
            class_name="flex gap-4 mt-4",
        ),
        rx.el.button(
            "View & Apply",
            on_click=lambda: PMAJAYState.open_scheme_dialog(scheme),
            class_name="mt-4 w-full py-2 px-4 bg-blue-500 text-white rounded-lg hover:bg-blue-600 font-medium transition-colors",
        ),
        class_name="bg-white p-4 rounded-xl border border-gray-200 shadow-sm hover:shadow-lg transition-shadow",
    )


def training_card(program: TrainingProgram) -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.icon("school", class_name="text-green-500"),
            rx.el.h3(program["program_name"], class_name="font-semibold text-gray-800"),
            class_name="flex items-center gap-3",
        ),
        rx.el.p(program["description"], class_name="text-sm text-gray-600 mt-2"),
        rx.el.div(
            rx.el.div(
                rx.el.p("Duration", class_name="text-xs text-gray-500"),
                rx.el.p(
                    program["duration"], class_name="text-sm font-medium text-gray-800"
                ),
            ),
            rx.el.div(
                rx.el.p("Location", class_name="text-xs text-gray-500"),
                rx.el.p(
                    program["location"], class_name="text-sm font-medium text-gray-800"
                ),
            ),
            rx.el.div(
                rx.el.p("Seats", class_name="text-xs text-gray-500"),
                rx.el.p(
                    program["seats"], class_name="text-sm font-medium text-gray-800"
                ),
            ),
            class_name="grid grid-cols-3 gap-4 mt-4",
        ),
        rx.el.button(
            "Enroll Now",
            on_click=lambda: PMAJAYState.open_training_dialog(program),
            class_name="mt-4 w-full py-2 px-4 bg-green-500 text-white rounded-lg hover:bg-green-600 font-medium transition-colors",
        ),
        class_name="bg-white p-4 rounded-xl border border-gray-200 shadow-sm hover:shadow-lg transition-shadow",
    )


def business_card(business: BusinessProfile) -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.icon("briefcase", class_name="text-purple-500"),
            rx.el.h3(
                business["business_name"], class_name="font-semibold text-gray-800"
            ),
            class_name="flex items-center gap-3 mb-2",
        ),
        rx.el.p(
            f"Type: {business['business_type']}", class_name="text-sm text-gray-600"
        ),
        rx.el.p(f"Sector: {business['sector']}", class_name="text-sm text-gray-600"),
        rx.el.p(
            f"Help Needed: {business['help_needed']}",
            class_name="text-sm text-gray-600 mt-2 italic",
        ),
        class_name="bg-white p-4 rounded-xl border border-gray-200 shadow-sm",
    )


def product_card(product: Product) -> rx.Component:
    return rx.el.div(
        rx.image(
            src="/placeholder.svg", class_name="w-full h-32 object-cover rounded-t-xl"
        ),
        rx.el.div(
            rx.el.h3(product["product_name"], class_name="font-semibold text-gray-800"),
            rx.el.p(
                f"₹{product['price']}", class_name="font-bold text-lg text-blue-600"
            ),
            class_name="flex justify-between items-start",
        ),
        rx.el.p(product["description"], class_name="text-sm text-gray-600 mt-1"),
        rx.el.p(
            f"Category: {product['category']}", class_name="text-xs text-gray-500 mt-2"
        ),
        class_name="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden",
    )


def stat_card(title: str, value: str, icon_name: str, color: str) -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.icon(icon_name, size=24, class_name=f"text-{color}-500"),
            class_name=f"p-3 bg-{color}-100 rounded-lg",
        ),
        rx.el.div(
            rx.el.p(title, class_name="text-sm text-gray-500 font-medium"),
            rx.el.p(value, class_name="text-2xl font-bold text-gray-800"),
            class_name="ml-4",
        ),
        class_name="flex items-center bg-white p-4 rounded-xl border border-gray-200 shadow-sm",
    )