import reflex as rx
from app.states.ai_state import AIState


def doc_scan_page() -> rx.Component:
    return rx.el.div(
        rx.el.h3(
            "Document Scanner (OCR)",
            class_name="text-xl font-semibold text-gray-800 mb-4",
        ),
        rx.el.div(
            rx.el.div(
                rx.upload.root(
                    rx.el.div(
                        rx.icon("upload", class_name="text-gray-500 mb-2"),
                        rx.text("Drag & drop or click to upload a document image."),
                        class_name="flex flex-col items-center justify-center p-8 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50",
                    ),
                    id="ocr_upload",
                    on_drop=AIState.handle_ocr_upload,
                    border="0",
                    padding="0",
                ),
                rx.button(
                    "Clear",
                    on_click=AIState.clear_ocr_state,
                    class_name="mt-4 px-4 py-2 bg-gray-200 text-gray-800 rounded-lg",
                ),
                class_name="w-full md:w-1/2",
            ),
            rx.el.div(
                rx.cond(
                    AIState.is_processing_ocr,
                    rx.el.div(
                        rx.spinner(size="3"),
                        rx.text("Extracting text...", class_name="mt-2 text-gray-500"),
                        class_name="flex flex-col items-center justify-center h-full bg-gray-50 rounded-lg",
                    ),
                    rx.cond(
                        AIState.uploaded_image_filename != "",
                        rx.el.div(
                            rx.el.h4(
                                "Uploaded Document", class_name="font-semibold mb-2"
                            ),
                            rx.image(
                                src=rx.get_upload_url(AIState.uploaded_image_filename),
                                class_name="max-h-64 w-auto rounded-lg border",
                            ),
                            rx.el.h4(
                                "Extracted Text", class_name="font-semibold mt-4 mb-2"
                            ),
                            rx.el.div(
                                rx.text(AIState.extracted_text, white_space="pre-wrap"),
                                class_name="p-4 bg-white border rounded-lg max-h-64 overflow-y-auto",
                            ),
                            rx.cond(
                                AIState.ocr_error != "",
                                rx.el.div(
                                    rx.icon(
                                        "badge_alert", class_name="text-red-500 mr-2"
                                    ),
                                    rx.text(AIState.ocr_error),
                                    class_name="flex items-center mt-2 text-red-600 bg-red-100 p-2 rounded-md",
                                ),
                            ),
                        ),
                        rx.el.div(
                            rx.icon("scan-text", class_name="text-gray-400 mb-2"),
                            rx.text(
                                "Upload a document to see the extracted text here."
                            ),
                            class_name="flex flex-col items-center justify-center h-full text-center text-gray-500 bg-gray-50 rounded-lg p-8",
                        ),
                    ),
                ),
                class_name="w-full md:w-1/2 p-4",
            ),
            class_name="flex flex-col md:flex-row gap-6 bg-white p-6 rounded-xl border",
        ),
        class_name="p-6",
    )