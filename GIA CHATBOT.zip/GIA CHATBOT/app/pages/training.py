import reflex as rx
from app.states.pmajay_state import PMAJAYState
from app.components.cards import training_card


def training_page() -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.foreach(PMAJAYState.training_programs, training_card),
            class_name="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6",
        ),
        class_name="p-6",
    )