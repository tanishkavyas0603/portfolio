import reflex as rx
from app.states.pmajay_state import PMAJAYState
from app.components.cards import stat_card, scheme_card, training_card


def dashboard_page() -> rx.Component:
    return rx.el.div(
        rx.el.h3("Overview", class_name="text-xl font-semibold text-gray-800 mb-4"),
        rx.el.div(
            stat_card("Schemes Applied", "0", "award", "blue"),
            stat_card("Trainings Enrolled", "0", "school", "green"),
            stat_card(
                "Businesses",
                PMAJAYState.business_profiles.length().to_string(),
                "briefcase",
                "purple",
            ),
            stat_card(
                "Products Listed",
                PMAJAYState.products.length().to_string(),
                "package",
                "orange",
            ),
            class_name="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6",
        ),
        rx.el.div(
            rx.el.div(
                rx.el.h3(
                    "Featured Schemes",
                    class_name="text-xl font-semibold text-gray-800 mb-4",
                ),
                rx.el.div(
                    rx.foreach(
                        PMAJAYState.schemes.range(
                            rx.cond(
                                PMAJAYState.schemes.length() > 2,
                                2,
                                PMAJAYState.schemes.length(),
                            )
                        ),
                        lambda i: scheme_card(PMAJAYState.schemes[i]),
                    ),
                    class_name="grid grid-cols-1 lg:grid-cols-2 gap-6",
                ),
            ),
            rx.el.div(
                rx.el.h3(
                    "Recommended Training",
                    class_name="text-xl font-semibold text-gray-800 mb-4",
                ),
                rx.el.div(
                    rx.foreach(
                        PMAJAYState.training_programs.range(
                            rx.cond(
                                PMAJAYState.training_programs.length() > 2,
                                2,
                                PMAJAYState.training_programs.length(),
                            )
                        ),
                        lambda i: training_card(PMAJAYState.training_programs[i]),
                    ),
                    class_name="grid grid-cols-1 lg:grid-cols-2 gap-6",
                ),
            ),
            class_name="mt-8 space-y-8",
        ),
        class_name="p-6",
    )