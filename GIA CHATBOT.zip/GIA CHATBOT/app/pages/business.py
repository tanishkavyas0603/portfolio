import reflex as rx
from app.states.pmajay_state import PMAJAYState
from app.components.cards import business_card
from app.components.forms import business_form


def business_page() -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.el.h3("Your Businesses", class_name="text-xl font-semibold"),
            rx.el.button(
                rx.icon("plus", class_name="mr-2"),
                "Add Business",
                on_click=PMAJAYState.toggle_business_form,
                class_name="px-4 py-2 bg-purple-500 text-white rounded-lg flex items-center hover:bg-purple-600",
            ),
            class_name="flex justify-between items-center mb-4",
        ),
        rx.cond(PMAJAYState.show_business_form, business_form()),
        rx.cond(
            PMAJAYState.business_profiles.length() > 0,
            rx.el.div(
                rx.foreach(PMAJAYState.business_profiles, business_card),
                class_name="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4",
            ),
            rx.el.div(
                rx.icon("info", class_name="text-gray-400 mb-2"),
                rx.el.p("No business profiles added yet.", class_name="text-gray-500"),
                class_name="flex flex-col items-center justify-center text-center p-12 bg-gray-50 rounded-xl border-2 border-dashed mt-4",
            ),
        ),
        class_name="p-6",
    )