import reflex as rx
from app.states.pmajay_state import PMAJAYState
from app.components.cards import product_card
from app.components.forms import product_form


def products_page() -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.el.h3("Your Products", class_name="text-xl font-semibold"),
            rx.el.button(
                rx.icon("plus", class_name="mr-2"),
                "Add Product",
                on_click=PMAJAYState.toggle_product_form,
                class_name="px-4 py-2 bg-orange-500 text-white rounded-lg flex items-center hover:bg-orange-600",
            ),
            class_name="flex justify-between items-center mb-4",
        ),
        rx.cond(PMAJAYState.show_product_form, product_form()),
        rx.cond(
            PMAJAYState.products.length() > 0,
            rx.el.div(
                rx.foreach(PMAJAYState.products, product_card),
                class_name="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mt-4",
            ),
            rx.el.div(
                rx.icon("package-search", class_name="text-gray-400 mb-2"),
                rx.el.p("No products listed yet.", class_name="text-gray-500"),
                class_name="flex flex-col items-center justify-center text-center p-12 bg-gray-50 rounded-xl border-2 border-dashed mt-4",
            ),
        ),
        class_name="p-6",
    )