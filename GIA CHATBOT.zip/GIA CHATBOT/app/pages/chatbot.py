import reflex as rx
from app.states.ai_state import AIState, Message


def message_bubble(message: Message) -> rx.Component:
    is_user = message["role"] == "user"
    return rx.el.div(
        rx.el.div(
            rx.text(message["content"], class_name="text-sm"),
            class_name=rx.cond(
                is_user,
                "bg-blue-500 text-white p-3 rounded-lg max-w-md",
                "bg-gray-200 text-gray-800 p-3 rounded-lg max-w-md",
            ),
        ),
        class_name=rx.cond(
            is_user, "flex justify-end w-full", "flex justify-start w-full"
        ),
    )


def chatbot_page() -> rx.Component:
    return rx.el.div(
        rx.el.h3(
            "AI Chat Assistant", class_name="text-xl font-semibold text-gray-800 mb-4"
        ),
        rx.cond(
            AIState.gemini_api_key_error,
            rx.el.div(
                rx.icon("flag_triangle_right", class_name="text-red-500 mr-2"),
                rx.text(
                    "Gemini API Key not found. Please set the GEMINI_API_KEY environment variable."
                ),
                class_name="flex items-center bg-red-100 p-4 rounded-lg text-red-700 mb-4",
            ),
        ),
        rx.el.div(
            rx.foreach(AIState.get_chat_history, message_bubble),
            rx.cond(
                AIState.is_processing_chat,
                rx.el.div(
                    rx.spinner(size="2"),
                    rx.text("Assistant is thinking..."),
                    class_name="flex items-center gap-2 text-gray-500 p-3",
                ),
            ),
            class_name="flex-1 flex flex-col gap-4 p-4 overflow-y-auto h-[65vh] bg-white border rounded-lg",
        ),
        rx.el.form(
            rx.el.input(
                placeholder="Ask about PM-AJAY schemes, eligibility, or anything else...",
                name="question",
                class_name="flex-1 p-3 border rounded-l-lg focus:outline-none focus:ring-2 focus:ring-blue-500",
                disabled=AIState.is_processing_chat | AIState.gemini_api_key_error,
            ),
            rx.el.button(
                rx.icon("send", size=20),
                type="submit",
                class_name="p-3 bg-blue-500 text-white rounded-r-lg hover:bg-blue-600 disabled:bg-blue-300",
                disabled=AIState.is_processing_chat | AIState.gemini_api_key_error,
            ),
            on_submit=AIState.answer_question,
            reset_on_submit=True,
            class_name="flex mt-4",
            width="100%",
        ),
        class_name="p-6 flex flex-col h-full",
    )