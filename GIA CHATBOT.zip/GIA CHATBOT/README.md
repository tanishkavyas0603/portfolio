# PM-AJAY GIA - Government Intervention Assistant

A comprehensive full-stack application designed to help beneficiaries of government schemes (PM-AJAY and similar programs) by providing intelligent eligibility prediction, skill recommendations, and income-generating activity suggestions.

## 🌟 Features

### 1. **Machine Learning API (FastAPI)**
- **Scheme Eligibility Prediction**: ML-powered eligibility scoring using Random Forest Classifier
- **Skill Recommendations**: Market-driven skill suggestions based on demand, growth rate, and beneficiary profile
- **Income Activity Recommendations**: Personalized business ideas based on investment capacity and existing skills
- **Explainable AI**: Detailed score breakdowns and actionable recommendations

### 2. **Interactive Dashboard (Reflex)**
- **Dashboard**: Overview of schemes, trainings, businesses, and products
- **Schemes Management**: Browse and apply for government schemes
- **Training Programs**: Discover and enroll in skill development programs
- **Business Profiles**: Manage entrepreneurship ventures
- **Product Marketplace**: List and showcase products
- **AI Chatbot**: Get instant answers about schemes and programs (powered by OpenAI)
- **Document Scanner**: OCR-based document text extraction

## 🏗️ Architecture

```
PM-AJAY GIA/
├── main.py                 # FastAPI ML Service
├── config.py              # Reflex configuration
├── requirements.txt       # Python dependencies
├── .env                   # Environment variables (create from .env.example)
├── .env.example          # Environment template
├── analysis.md           # Project analysis documentation
└── app/                  # Reflex Frontend Application
    ├── app.py            # Main app entry point
    ├── components/       # Reusable UI components
    │   ├── cards.py      # Card components (scheme, training, business, product)
    │   ├── dialogs.py    # Modal dialogs
    │   ├── forms.py      # Form components
    │   ├── header.py     # Header component
    │   └── sidebar.py    # Navigation sidebar
    ├── pages/            # Application pages
    │   ├── dashboard.py  # Main dashboard
    │   ├── scheme.py     # Schemes listing
    │   ├── training.py   # Training programs
    │   ├── business.py   # Business management
    │   ├── product.py    # Product marketplace
    │   ├── chatbot.py    # AI assistant
    │   └── doc_scan.py   # Document scanner
    └── states/           # Application state management
        ├── pmajay_state.py  # Main application state
        └── ai_state.py      # AI/OCR state
```

## 🚀 Getting Started

### Prerequisites
- Python 3.10 or higher
- pip (Python package manager)
- Tesseract OCR (for document scanning)
- OpenAI API key (for chatbot functionality)

### Installation

1. **Clone or navigate to the project directory**
```bash
cd c:\Users\athrv\OneDrive\Desktop\GIA
```

2. **Create a virtual environment**
```bash
python -m venv .venv
```

3. **Activate the virtual environment**
```bash
# Windows
.venv\Scripts\activate

# Linux/Mac
source .venv/bin/activate
```

4. **Install dependencies**
```bash
pip install -r requirements.txt
```

5. **Set up environment variables**
```bash
# Copy the example file
copy .env.example .env

# Edit .env and add your OpenAI API key
# GEMINI_API_KEY=AIzaSyASGJUjuCJ_FkRoyMBm3dRCkYD3G8w6oiQ
```

6. **Install Tesseract OCR (for document scanning)**
- **Windows**: Download from https://github.com/UB-Mannheim/tesseract/wiki
- **Linux**: `sudo apt-get install tesseract-ocr`
- **Mac**: `brew install tesseract`

## 🎯 Running the Application

### Option 1: Run Both Services Together (Recommended)

**Terminal 1 - FastAPI ML Service:**
```bash
uvicorn main:app --reload --port 8000
```

**Terminal 2 - Reflex Frontend:**
```bash
reflex run
```

The application will be available at:
- **Frontend**: http://localhost:3000
- **ML API**: http://localhost:8000
- **API Docs**: http://localhost:8000/docs

### Option 2: Run Services Separately

**Run only the ML API:**
```bash
uvicorn main:app --reload --port 8000
```

**Run only the Frontend:**
```bash
reflex run
```

## 📊 API Endpoints

### 1. Predict Eligibility
```http
POST /predict-eligibility
Content-Type: application/json

{
  "beneficiary": {
    "age": 28,
    "gender": "Female",
    "caste_category": "SC",
    "family_annual_income": 150000,
    "education_level": "Graduate",
    "skills_possessed": ["Tailoring", "Digital Marketing"],
    "employment_status": "Self-Employed",
    "district": "Delhi",
    "state": "Delhi",
    "disability_status": false,
    "household_size": 4,
    "land_ownership": false,
    "existing_business": true
  },
  "scheme_id": "stand-up-india",
  "scheme_criteria": {
    "max_income": 300000,
    "categories": ["SC", "ST"],
    "min_education": "10th Pass"
  }
}
```

### 2. Recommend Skills
```http
POST /recommend-skills
Content-Type: application/json

{
  "beneficiary": {
    "age": 25,
    "gender": "Male",
    "education_level": "Graduate",
    "existing_business": false,
    "state": "Karnataka",
    ...
  }
}
```

### 3. Recommend Income Activities
```http
POST /recommend-income-activity
Content-Type: application/json

{
  "beneficiary": {...},
  "investment_capacity": 50000,
  "available_time_hours": 8
}
```

## 🛠️ Technology Stack

### Backend (ML Service)
- **FastAPI**: Modern, fast web framework
- **Scikit-learn**: Machine learning models
- **Pandas & NumPy**: Data processing
- **Joblib**: Model serialization

### Frontend (Dashboard)
- **Reflex**: Full-stack Python framework
- **TailwindCSS**: Styling
- **OpenAI**: AI chatbot
- **Tesseract OCR**: Document scanning
- **OpenCV**: Image processing

## 📁 Key Components

### Machine Learning Models

**EligibilityPredictor**
- Random Forest Classifier for scheme eligibility
- Rule-based fallback system
- Automatic model training on startup
- Score breakdown and recommendations

**SkillRecommender**
- Market demand-based scoring
- Profile-specific recommendations
- Growth rate and income potential analysis

**IncomeActivityRecommender**
- Investment-based filtering
- Skill matching algorithm
- ROI-focused suggestions

### Frontend Features

**State Management**
- Reactive state with Reflex
- Centralized data management
- Real-time updates

**UI Components**
- Responsive design
- Modern card-based layouts
- Interactive dialogs and forms

## 🔧 Configuration

### Reflex Configuration (`config.py`)
```python
import reflex as rx

config = rx.Config(
    app_name="app",
    plugins=[rx.plugins.TailwindV3Plugin()]
)
```

### Environment Variables
- `GEMINI_API_KEY`: Required for AI chatbot (Google Gemini)
- `DATABASE_URL`: Optional database connection
- `ML_SERVICE_URL`: ML API endpoint (default: http://localhost:8000)

## 📝 Development

### Adding New Schemes
Edit `app/states/pmajay_state.py` and add to the `schemes` list in `fetch_all_data()`.

### Adding New Training Programs
Edit `app/states/pmajay_state.py` and add to the `training_programs` list.

### Customizing ML Models
Edit `main.py` to modify:
- Feature engineering in `EligibilityPredictor`
- Skill database in `SkillRecommender.build_skill_database()`
- Activity database in `IncomeActivityRecommender.build_activity_database()`

## 🐛 Troubleshooting

### Issue: Tesseract not found
**Solution**: Install Tesseract and add to PATH, or set `pytesseract.pytesseract.tesseract_cmd` in `ai_state.py`

### Issue: OpenAI API errors
**Solution**: Verify your API key in `.env` file and check your OpenAI account credits

### Issue: Model not loading
**Solution**: Delete `eligibility_model.joblib` and restart - a new model will be trained automatically

### Issue: Port already in use
**Solution**: Change ports in startup commands:
```bash
uvicorn main:app --reload --port 8001
reflex run --frontend-port 3001
```

## 📄 License

This project is created for educational and social welfare purposes.

## 🤝 Contributing

Contributions are welcome! Please feel free to submit issues or pull requests.

## 📧 Support

For questions or support, please refer to the `analysis.md` file for detailed project documentation.

---

**Built with ❤️ for social empowerment through technology**
