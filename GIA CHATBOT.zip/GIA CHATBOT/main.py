from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional, Dict
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier, GradientBoostingRegressor
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics.pairwise import cosine_similarity
import joblib
import os

app = FastAPI(title="PM-AJAY ML Service")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class BeneficiaryProfile(BaseModel):
    age: int
    gender: str
    caste_category: str
    family_annual_income: float
    education_level: str
    skills_possessed: List[str]
    employment_status: str
    district: str
    state: str
    disability_status: bool
    household_size: int
    land_ownership: bool
    existing_business: bool

class SchemeEligibilityRequest(BaseModel):
    beneficiary: BeneficiaryProfile
    scheme_id: str
    scheme_criteria: Dict

class SkillRecommendationRequest(BaseModel):
    beneficiary: BeneficiaryProfile

class IncomeActivityRequest(BaseModel):
    beneficiary: BeneficiaryProfile
    investment_capacity: float
    available_time_hours: int

# ==================== ELIGIBILITY PREDICTION MODEL ====================
class EligibilityPredictor:
    def __init__(self, model_path="eligibility_model.joblib"):
        self.model_path = model_path
        self.model = None
        self.scaler = StandardScaler()
        self.label_encoders = {}
        if os.path.exists(self.model_path):
            self.load_model()
        
    def train_model(self, training_data: pd.DataFrame):
        """Train eligibility prediction model"""
        features = [
            'age', 'family_annual_income', 'household_size',
            'education_level', 'gender', 'caste_category',
            'employment_status', 'existing_business', 'land_ownership'
        ]
        
        categorical_features = ['education_level', 'gender', 'caste_category', 'employment_status']
        
        for col in categorical_features:
            if col in training_data.columns:
                le = LabelEncoder()
                training_data[f'{col}_encoded'] = le.fit_transform(training_data[col].fillna('Unknown'))
                self.label_encoders[col] = le
        
        feature_cols = ['age', 'family_annual_income', 'household_size'] + \
                      [f'{col}_encoded' for col in categorical_features] + \
                      ['existing_business', 'land_ownership']
        
        X = training_data[feature_cols]
        y = training_data['eligible']
        
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        
        self.model = RandomForestClassifier(
            n_estimators=100, max_depth=10, min_samples_split=20, random_state=42
        )
        self.model.fit(X_train_scaled, y_train)
        
        accuracy = self.model.score(X_test_scaled, y_test)
        print(f"Model Accuracy: {accuracy:.2f}")
        self.save_model()
        
    def save_model(self):
        joblib.dump({
            'model': self.model,
            'scaler': self.scaler,
            'label_encoders': self.label_encoders
        }, self.model_path)
        print(f"Model saved to {self.model_path}")

    def load_model(self):
        data = joblib.load(self.model_path)
        self.model = data['model']
        self.scaler = data['scaler']
        self.label_encoders = data['label_encoders']
        print(f"Model loaded from {self.model_path}")
    
    def predict_eligibility(self, beneficiary: BeneficiaryProfile, scheme_criteria: Dict) -> Dict:
        """Predict eligibility score for a beneficiary"""
        features = {
            'age': beneficiary.age,
            'family_annual_income': beneficiary.family_annual_income,
            'household_size': beneficiary.household_size,
            'existing_business': int(beneficiary.existing_business),
            'land_ownership': int(beneficiary.land_ownership)
        }
        
        categorical_map = {
            'education_level': beneficiary.education_level,
            'gender': beneficiary.gender,
            'caste_category': beneficiary.caste_category,
            'employment_status': beneficiary.employment_status
        }
        
        for col, value in categorical_map.items():
            if col in self.label_encoders:
                try:
                    encoded_val = self.label_encoders[col].transform([value])[0]
                except ValueError: # Handle unseen labels
                    encoded_val = -1
                features[f'{col}_encoded'] = encoded_val
        
        feature_df = pd.DataFrame([features])
        
        if self.model:
            feature_scaled = self.scaler.transform(feature_df)
            eligibility_prob = self.model.predict_proba(feature_scaled)[0][1]
        else:
            eligibility_prob = self._rule_based_eligibility(beneficiary, scheme_criteria)
        
        score_breakdown = self._calculate_score_breakdown(beneficiary, scheme_criteria)
        
        return {
            'eligibility_score': round(eligibility_prob * 100, 2),
            'is_eligible': eligibility_prob >= 0.6,
            'confidence': round(eligibility_prob, 3),
            'score_breakdown': score_breakdown,
            'recommendations': self._generate_recommendations(beneficiary, scheme_criteria, eligibility_prob)
        }
    
    def _rule_based_eligibility(self, beneficiary: BeneficiaryProfile, criteria: Dict) -> float:
        """Rule-based eligibility calculation as fallback"""
        score = 0.5
        if 'max_income' in criteria and beneficiary.family_annual_income <= criteria['max_income']: score += 0.2
        if 'categories' in criteria and beneficiary.caste_category in criteria['categories']: score += 0.15
        if 'min_education' in criteria:
            education_levels = ['Below 10th', '10th Pass', '12th Pass', 'Graduate', 'Post Graduate']
            beneficiary_level = education_levels.index(beneficiary.education_level) if beneficiary.education_level in education_levels else 0
            required_level = education_levels.index(criteria['min_education']) if criteria['min_education'] in education_levels else 0
            if beneficiary_level >= required_level: score += 0.15
        return min(score, 1.0)
    
    def _calculate_score_breakdown(self, beneficiary: BeneficiaryProfile, criteria: Dict) -> Dict:
        """Calculate detailed score breakdown"""
        breakdown = {'income_criteria': 0, 'category_criteria': 0, 'education_criteria': 0, 'business_criteria': 0, 'documentation': 0}
        if 'max_income' in criteria and beneficiary.family_annual_income <= criteria['max_income']: breakdown['income_criteria'] = 20
        if 'categories' in criteria and beneficiary.caste_category in criteria['categories']: breakdown['category_criteria'] = 25
        if 'min_education' in criteria: breakdown['education_criteria'] = 15
        if beneficiary.existing_business: breakdown['business_criteria'] = 20
        breakdown['documentation'] = 20 # Assumed complete
        return breakdown
    
    def _generate_recommendations(self, beneficiary: BeneficiaryProfile, criteria: Dict, score: float) -> List[str]:
        """Generate personalized recommendations"""
        recommendations = []
        if score < 0.6:
            if 'max_income' in criteria and beneficiary.family_annual_income > criteria['max_income']: recommendations.append("Consider schemes with higher income limits.")
            if 'min_education' in criteria: recommendations.append("Explore skill development programs to enhance qualifications.")
            if not beneficiary.existing_business: recommendations.append("Register a business to access entrepreneurship schemes.")
        else:
            recommendations.append("You are likely eligible! Submit your application soon.")
            recommendations.append("Prepare all required documents for faster processing.")
        return recommendations

class SkillRecommender:
    def __init__(self):
        self.skill_market_demand = {}
    
    def build_skill_database(self):
        """Build skill database with market demand and income potential"""
        self.skill_market_demand = {
            'Digital Marketing': {'demand_score': 92, 'avg_income': 25000, 'growth_rate': 18},
            'Web Development': {'demand_score': 95, 'avg_income': 35000, 'growth_rate': 20},
            'Data Analysis': {'demand_score': 88, 'avg_income': 40000, 'growth_rate': 22},
            'Tailoring': {'demand_score': 75, 'avg_income': 15000, 'growth_rate': 8},
            'Food Processing': {'demand_score': 80, 'avg_income': 18000, 'growth_rate': 12},
            'Mobile Repair': {'demand_score': 70, 'avg_income': 20000, 'growth_rate': 10},
            'Beauty & Wellness': {'demand_score': 78, 'avg_income': 22000, 'growth_rate': 14},
            'E-commerce Management': {'demand_score': 90, 'avg_income': 28000, 'growth_rate': 25},
            'Accounting': {'demand_score': 72, 'avg_income': 24000, 'growth_rate': 8},
            'Handicrafts': {'demand_score': 68, 'avg_income': 16000, 'growth_rate': 6},
            'Agriculture Tech': {'demand_score': 85, 'avg_income': 30000, 'growth_rate': 16},
            'Solar Installation': {'demand_score': 82, 'avg_income': 26000, 'growth_rate': 18},
        }
    
    def recommend_skills(self, beneficiary: BeneficiaryProfile, top_n: int = 5) -> List[Dict]:
        """Recommend skills based on beneficiary profile and market demand"""
        recommendations = []
        
        for skill, data in self.skill_market_demand.items():
            base_score = data['demand_score']
            if beneficiary.education_level in ['Graduate', 'Post Graduate'] and skill in ['Web Development', 'Data Analysis', 'Digital Marketing']: base_score += 10
            if beneficiary.existing_business and skill in ['E-commerce Management', 'Digital Marketing', 'Accounting']: base_score += 8
            if beneficiary.age < 30 and skill in ['Web Development', 'Digital Marketing', 'Data Analysis']: base_score += 5
            
            income_score = (data['avg_income'] / 40000) * 30
            growth_score = (data['growth_rate'] / 25) * 20
            total_score = base_score + income_score + growth_score
            
            recommendations.append({
                'skill': skill, 'recommendation_score': round(total_score, 2),
                'market_demand': data['demand_score'], 'average_income': data['avg_income'],
                'growth_rate': data['growth_rate'], 'training_duration': self._estimate_training_duration(skill),
                'job_opportunities': self._estimate_job_opportunities(skill, beneficiary.state)
            })
        
        recommendations.sort(key=lambda x: x['recommendation_score'], reverse=True)
        return recommendations[:top_n]
    
    def _estimate_training_duration(self, skill: str) -> str:
        """Estimate training duration for a given skill"""
        duration_map = {
            'Digital Marketing': "3-4 Months", 'Web Development': "4-6 Months", 'Data Analysis': "4-6 Months",
            'Tailoring': "2-3 Months", 'Food Processing': "3 Months", 'Mobile Repair': "2 Months",
            'Beauty & Wellness': "3-4 Months", 'E-commerce Management': "3 Months", 'Accounting': "4 Months",
            'Handicrafts': "1-2 Months", 'Agriculture Tech': "4 Months", 'Solar Installation': "3 Months"
        }
        return duration_map.get(skill, "3 Months")

    def _estimate_job_opportunities(self, skill: str, state: str) -> str:
        """Estimate job opportunities based on skill and state"""
        # In a real system, this would query a job portal API or a local economic database.
        # Here we use a heuristic.
        high_tech_states = ['Karnataka', 'Maharashtra', 'Telangana', 'Haryana']
        agri_states = ['Punjab', 'Uttar Pradesh', 'Madhya Pradesh']
        
        if skill in ['Web Development', 'Data Analysis', 'E-commerce Management'] and state in high_tech_states:
            return "High"
        if skill in ['Agriculture Tech', 'Food Processing'] and state in agri_states:
            return "High"
        if skill in ['Tailoring', 'Handicrafts', 'Beauty & Wellness']:
            return "Medium (pan-India)"
        return "Medium"

# ==================== INCOME ACTIVITY RECOMMENDATION ====================
class IncomeActivityRecommender:
    def __init__(self):
        self.activities = []

    def build_activity_database(self):
        """Build a database of income-generating activities"""
        self.activities = [
            {'activity': 'Small Kirana Store', 'min_investment': 50000, 'potential_income': 20000, 'required_skills': ['Accounting', 'Sales']},
            {'activity': 'Food Cart (e.g., Momos, Chaat)', 'min_investment': 25000, 'potential_income': 25000, 'required_skills': ['Cooking', 'Sales']},
            {'activity': 'Tailoring & Alteration Shop', 'min_investment': 30000, 'potential_income': 18000, 'required_skills': ['Tailoring']},
            {'activity': 'E-commerce Reselling', 'min_investment': 15000, 'potential_income': 22000, 'required_skills': ['E-commerce Management', 'Digital Marketing']},
            {'activity': 'Handicrafts Business (Online)', 'min_investment': 10000, 'potential_income': 15000, 'required_skills': ['Handicrafts', 'E-commerce Management']},
            {'activity': 'Mobile Repair Kiosk', 'min_investment': 40000, 'potential_income': 28000, 'required_skills': ['Mobile Repair']},
            {'activity': 'Home-based Tiffin Service', 'min_investment': 20000, 'potential_income': 30000, 'required_skills': ['Cooking', 'Time Management']}
        ]

    def recommend_activities(self, req: IncomeActivityRequest, top_n: int = 3) -> List[Dict]:
        """Recommend income-generating activities"""
        eligible_activities = [
            act for act in self.activities 
            if act['min_investment'] <= req.investment_capacity
        ]

        for act in eligible_activities:
            # Score based on profit margin and alignment with existing skills
            profit_score = (act['potential_income'] / act['min_investment']) * 50
            skill_match_score = 50 if any(skill in req.beneficiary.skills_possessed for skill in act['required_skills']) else 0
            act['recommendation_score'] = round(profit_score + skill_match_score, 2)
        
        eligible_activities.sort(key=lambda x: x['recommendation_score'], reverse=True)
        return eligible_activities[:top_n]


# ==================== GLOBAL INSTANCES & STARTUP ====================
eligibility_predictor = EligibilityPredictor()
skill_recommender = SkillRecommender()
income_recommender = IncomeActivityRecommender()

@app.on_event("startup")
async def startup_event():
    """Tasks to run when the application starts."""
    print("Starting up ML Service...")
    # Build skill and activity databases
    skill_recommender.build_skill_database()
    income_recommender.build_activity_database()

    # If the eligibility model doesn't exist, train a dummy one
    if not os.path.exists(eligibility_predictor.model_path):
        print("Eligibility model not found. Training a dummy model...")
        # Create dummy data
        data = {
            'age': np.random.randint(18, 60, 500),
            'family_annual_income': np.random.uniform(20000, 500000, 500),
            'household_size': np.random.randint(1, 10, 500),
            'education_level': np.random.choice(['10th Pass', '12th Pass', 'Graduate'], 500),
            'gender': np.random.choice(['Male', 'Female'], 500),
            'caste_category': np.random.choice(['SC', 'ST'], 500),
            'employment_status': np.random.choice(['Unemployed', 'Self-Employed'], 500),
            'existing_business': np.random.choice([True, False], 500),
            'land_ownership': np.random.choice([True, False], 500),
            'eligible': np.random.randint(0, 2, 500)
        }
        dummy_df = pd.DataFrame(data)
        eligibility_predictor.train_model(dummy_df)
    
    print("ML Service is ready.")

# ==================== API ENDPOINTS ====================
@app.get("/")
def read_root():
    return {"status": "PM-AJAY Machine Learning Service is running."}

@app.post("/predict-eligibility", summary="Predict Scheme Eligibility")
def predict_eligibility(request: SchemeEligibilityRequest):
    """
    Predicts if a beneficiary is eligible for a scheme based on their profile and scheme criteria.
    Returns an eligibility score, breakdown, and recommendations.
    """
    try:
        result = eligibility_predictor.predict_eligibility(request.beneficiary, request.scheme_criteria)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/recommend-skills", summary="Recommend Relevant Skills")
def recommend_skills(request: SkillRecommendationRequest):
    """
    Recommends top skills for a beneficiary based on their profile and market demand data.
    """
    try:
        skills = skill_recommender.recommend_skills(request.beneficiary)
        if not skills:
            raise HTTPException(status_code=404, detail="No suitable skills found for the given profile.")
        return {"recommended_skills": skills}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/recommend-income-activity", summary="Recommend Income-Generating Activities")
def recommend_income_activity(request: IncomeActivityRequest):
    """
    Recommends income-generating activities based on investment capacity, time, and existing skills.
    """
    try:
        activities = income_recommender.recommend_activities(request)
        if not activities:
            raise HTTPException(status_code=404, detail="No suitable activities found for the given criteria.")
        return {"recommended_activities": activities}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))