"""
API Testing Script for PM-AJAY ML Service

This script demonstrates how to interact with the ML API endpoints.
Run the FastAPI service first: uvicorn main:app --reload --port 8000
"""

import requests
import json

# Base URL for the API
BASE_URL = "http://localhost:8000"


def test_root():
    """Test the root endpoint"""
    print("\n" + "="*50)
    print("Testing Root Endpoint")
    print("="*50)
    
    response = requests.get(f"{BASE_URL}/")
    print(f"Status Code: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")


def test_predict_eligibility():
    """Test scheme eligibility prediction"""
    print("\n" + "="*50)
    print("Testing Eligibility Prediction")
    print("="*50)
    
    payload = {
        "beneficiary": {
            "age": 28,
            "gender": "Female",
            "caste_category": "SC",
            "family_annual_income": 150000,
            "education_level": "Graduate",
            "skills_possessed": ["Tailoring", "Digital Marketing"],
            "employment_status": "Self-Employed",
            "district": "Delhi",
            "state": "Delhi",
            "disability_status": False,
            "household_size": 4,
            "land_ownership": False,
            "existing_business": True
        },
        "scheme_id": "stand-up-india",
        "scheme_criteria": {
            "max_income": 300000,
            "categories": ["SC", "ST"],
            "min_education": "10th Pass"
        }
    }
    
    response = requests.post(f"{BASE_URL}/predict-eligibility", json=payload)
    print(f"Status Code: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")


def test_recommend_skills():
    """Test skill recommendation"""
    print("\n" + "="*50)
    print("Testing Skill Recommendation")
    print("="*50)
    
    payload = {
        "beneficiary": {
            "age": 25,
            "gender": "Male",
            "caste_category": "General",
            "family_annual_income": 200000,
            "education_level": "Graduate",
            "skills_possessed": ["Basic Computer"],
            "employment_status": "Unemployed",
            "district": "Bangalore",
            "state": "Karnataka",
            "disability_status": False,
            "household_size": 5,
            "land_ownership": False,
            "existing_business": False
        }
    }
    
    response = requests.post(f"{BASE_URL}/recommend-skills", json=payload)
    print(f"Status Code: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")


def test_recommend_income_activity():
    """Test income activity recommendation"""
    print("\n" + "="*50)
    print("Testing Income Activity Recommendation")
    print("="*50)
    
    payload = {
        "beneficiary": {
            "age": 30,
            "gender": "Female",
            "caste_category": "ST",
            "family_annual_income": 180000,
            "education_level": "12th Pass",
            "skills_possessed": ["Cooking", "Sales"],
            "employment_status": "Self-Employed",
            "district": "Mumbai",
            "state": "Maharashtra",
            "disability_status": False,
            "household_size": 3,
            "land_ownership": False,
            "existing_business": False
        },
        "investment_capacity": 50000,
        "available_time_hours": 8
    }
    
    response = requests.post(f"{BASE_URL}/recommend-income-activity", json=payload)
    print(f"Status Code: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")


def main():
    """Run all tests"""
    print("\n" + "="*50)
    print("PM-AJAY ML Service API Testing")
    print("="*50)
    print(f"Testing API at: {BASE_URL}")
    
    try:
        # Test all endpoints
        test_root()
        test_predict_eligibility()
        test_recommend_skills()
        test_recommend_income_activity()
        
        print("\n" + "="*50)
        print("All tests completed!")
        print("="*50)
        
    except requests.exceptions.ConnectionError:
        print("\n❌ ERROR: Could not connect to the API")
        print("Please make sure the FastAPI service is running:")
        print("  uvicorn main:app --reload --port 8000")
    except Exception as e:
        print(f"\n❌ ERROR: {str(e)}")


if __name__ == "__main__":
    main()
