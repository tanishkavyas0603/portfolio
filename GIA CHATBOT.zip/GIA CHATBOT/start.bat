@echo off
echo ========================================
echo PM-AJAY GIA - Starting Services
echo ========================================
echo.

REM Check if virtual environment exists
if not exist ".venv\Scripts\activate.bat" (
    echo Virtual environment not found!
    echo Please run: python -m venv .venv
    echo Then run: .venv\Scripts\activate
    echo Then run: pip install -r requirements.txt
    pause
    exit /b 1
)

echo Activating virtual environment...
call .venv\Scripts\activate.bat

echo.
echo Starting FastAPI ML Service on port 8000...
start "PM-AJAY ML Service" cmd /k "uvicorn main:app --reload --port 8000"

timeout /t 3 /nobreak >nul

echo Starting Reflex Frontend on port 3000...
start "PM-AJAY Frontend" cmd /k "reflex run"

echo.
echo ========================================
echo Services are starting...
echo.
echo ML API will be available at: http://localhost:8000
echo API Docs will be available at: http://localhost:8000/docs
echo Frontend will be available at: http://localhost:3000
echo.
echo Press any key to stop all services...
echo ========================================
pause >nul

echo.
echo Stopping services...
taskkill /FI "WindowTitle eq PM-AJAY ML Service*" /T /F
taskkill /FI "WindowTitle eq PM-AJAY Frontend*" /T /F

echo Services stopped.
pause
