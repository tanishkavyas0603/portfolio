# 🚀 n8n Quick Setup Guide for PM-AJAY GIA

## ⚡ Quick Start (15 Minutes)

### **Step 1: Start n8n (5 minutes)**

```bash
# Navigate to project directory
cd "c:\Users\athrv\OneDrive\Desktop\GIA CHATBOT"

# Create docker-compose-n8n.yml file
# (Copy content from N8N_AUTOMATION_ARCHITECTURE.md)

# Start n8n
docker-compose -f docker-compose-n8n.yml up -d

# Check if running
docker ps

# Access n8n UI
# Open browser: http://localhost:5678
```

### **Step 2: Initial Setup (5 minutes)**

1. **Create Admin Account**
   - Open http://localhost:5678
   - Set username and password
   - Complete setup wizard

2. **Configure Credentials**
   - Click **Settings** → **Credentials**
   - Add the following credentials:

#### **PostgreSQL Database**
```
Name: PostgreSQL - PM-AJAY
Type: Postgres
Host: localhost (or postgres if using Docker network)
Port: 5432
Database: pmajay_db
User: pmajay
Password: your_password
SSL: Disabled (for local development)
```

#### **SMTP Email**
```
Name: SMTP - PM-AJAY
Type: SMTP
Host: smtp.gmail.com (or your SMTP server)
Port: 587
User: your-email@gmail.com
Password: your-app-password
Secure: Use TLS
```

**Note:** For Gmail, create an App Password:
1. Go to Google Account → Security
2. Enable 2-Step Verification
3. Generate App Password
4. Use this password in n8n

#### **Twilio SMS (Optional)**
```
Name: Twilio Auth
Type: HTTP Basic Auth
User: YOUR_TWILIO_ACCOUNT_SID
Password: YOUR_TWILIO_AUTH_TOKEN
```

### **Step 3: Import Workflows (5 minutes)**

1. **Download Workflow Files**
   - Workflows are in: `n8n_workflows/` folder
   - Available workflows:
     - `1_beneficiary_registration.json`
     - `2_application_status_notifications.json`

2. **Import Workflows**
   - In n8n UI, click **Workflows** → **Import from File**
   - Select workflow JSON file
   - Click **Import**

3. **Configure Workflow**
   - Open imported workflow
   - Click on each node
   - Select appropriate credentials
   - Update any placeholder values (URLs, IDs, etc.)

4. **Test Workflow**
   - Click **Execute Workflow** button
   - Check execution log
   - Verify output

5. **Activate Workflow**
   - Toggle **Active** switch to ON
   - Workflow will now run automatically

---

## 📋 Workflow Checklist

### **Priority 1: Essential Workflows (Week 1)**
- [ ] 1. Beneficiary Registration Automation
- [ ] 2. Application Status Notifications
- [ ] 3. Welcome Email Series

### **Priority 2: Important Workflows (Week 2)**
- [ ] 4. Government Scheme Data Sync
- [ ] 5. Deadline Reminders
- [ ] 6. Weekly Analytics Report

### **Priority 3: Advanced Workflows (Week 3-4)**
- [ ] 7. ML Model Retraining
- [ ] 8. Data Validation & Cleanup
- [ ] 9. Performance Monitoring

---

## 🔧 Configuration Templates

### **Database Connection Test**
```sql
-- Test query to verify database connection
SELECT COUNT(*) as total_beneficiaries FROM beneficiaries;
```

### **Email Template Variables**
Available variables in email templates:
- `{{ $json.name }}` - Beneficiary name
- `{{ $json.email }}` - Email address
- `{{ $json.phone }}` - Phone number
- `{{ $json.scheme_name }}` - Scheme name
- `{{ $json.status }}` - Application status
- `{{ $json.id }}` - Application ID
- `{{ $now }}` - Current timestamp

### **Webhook URL Format**
```
http://localhost:5678/webhook/[webhook-name]
```

Example:
```
http://localhost:5678/webhook/application-created
```

---

## 🧪 Testing Workflows

### **Test 1: Beneficiary Registration**
1. Fill out Google Form (or create test form)
2. Submit form
3. Check n8n execution log
4. Verify email received
5. Check PostgreSQL database

```sql
-- Verify beneficiary was added
SELECT * FROM beneficiaries ORDER BY id DESC LIMIT 1;
```

### **Test 2: Application Notifications**
1. Manually update application status in database:
```sql
UPDATE applications 
SET status = 'Approved', notification_sent = false 
WHERE id = 1;
```
2. Wait for workflow to run (5 minutes)
3. Check email inbox
4. Verify SMS received (if configured)

### **Test 3: Webhook Integration**
```bash
# Test webhook with curl
curl -X POST http://localhost:5678/webhook/test \
  -H "Content-Type: application/json" \
  -d '{
    "beneficiary_id": 1,
    "scheme_id": 1,
    "status": "Pending"
  }'
```

---

## 📊 Monitoring & Logs

### **View Workflow Executions**
1. Go to **Executions** tab in n8n
2. Filter by workflow name
3. Click on execution to view details
4. Check each node's input/output

### **Enable Debug Mode**
```bash
# Add to docker-compose-n8n.yml
environment:
  - N8N_LOG_LEVEL=debug
  - N8N_LOG_OUTPUT=console,file
```

### **View Logs**
```bash
# Docker logs
docker logs n8n_pmajay -f

# Or in n8n UI
# Settings → Log Streaming
```

---

## 🚨 Troubleshooting

### **Issue: Workflow not triggering**
**Solution:**
1. Check if workflow is **Active** (toggle should be ON)
2. Verify trigger configuration (schedule, webhook URL)
3. Check execution logs for errors
4. Test manually with **Execute Workflow** button

### **Issue: Database connection failed**
**Solution:**
1. Verify PostgreSQL is running: `docker ps`
2. Check credentials in n8n
3. Test connection with SQL query
4. Ensure database exists: `pmajay_db`

### **Issue: Email not sending**
**Solution:**
1. Verify SMTP credentials
2. Check if using Gmail App Password (not regular password)
3. Test with a simple email node
4. Check spam folder
5. Review execution log for error messages

### **Issue: Webhook not receiving data**
**Solution:**
1. Verify webhook URL is correct
2. Check if workflow is active
3. Test with curl command
4. Ensure Content-Type is application/json
5. Check n8n logs for incoming requests

---

## 🎯 Next Steps

### **After Setup**
1. ✅ Test all workflows manually
2. ✅ Monitor executions for 24 hours
3. ✅ Optimize slow workflows
4. ✅ Set up error notifications
5. ✅ Create backup of workflows

### **Week 1 Goals**
- [ ] 3 essential workflows running
- [ ] 100+ automated emails sent
- [ ] 0 critical errors
- [ ] Database integration working

### **Week 2 Goals**
- [ ] 6 workflows operational
- [ ] 500+ automated actions
- [ ] Performance optimized
- [ ] Error handling tested

---

## 📚 Resources

### **n8n Documentation**
- Getting Started: https://docs.n8n.io/getting-started/
- Nodes: https://docs.n8n.io/integrations/builtin/
- Workflows: https://docs.n8n.io/workflows/

### **PM-AJAY GIA Specific**
- Full Architecture: `N8N_AUTOMATION_ARCHITECTURE.md`
- Workflow Files: `n8n_workflows/` folder
- API Docs: http://localhost:8000/docs

### **Support**
- n8n Community: https://community.n8n.io/
- GitHub Issues: https://github.com/n8n-io/n8n/issues

---

## ✅ Setup Verification

Run this checklist to verify everything is working:

- [ ] n8n UI accessible at http://localhost:5678
- [ ] PostgreSQL credentials configured
- [ ] SMTP credentials configured
- [ ] At least 1 workflow imported
- [ ] Workflow tested manually
- [ ] Workflow activated
- [ ] Execution log shows success
- [ ] Email received (if applicable)
- [ ] Database updated (if applicable)

---

**You're all set! Your n8n automation is ready to transform PM-AJAY GIA! 🚀**

---

**Last Updated:** January 22, 2026  
**Version:** 1.0
