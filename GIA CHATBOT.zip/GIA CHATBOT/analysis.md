# Project Analysis: PM-AJAY ML Service & Dashboard

## **1. Project Overview**
This project appears to be a comprehensive solution designed for the **PM-AJAY (Pradhan Mantri Adarsh Gram Yojana)** or a similar social welfare scheme context. It combines a **Machine Learning API** for eligibility and recommendations with a **Frontend Dashboard** built using the Reflex framework.

The system is designed to help beneficiaries or administrators by:
- Predicting eligibility for government schemes.
- Recommending suitable skills based on market trends.
- Suggesting income-generating activities (small businesses).
- Providing a user interface to manage these aspects, including a chatbot and document scanner.

---

## **2. Architecture**
The project is structured as a full-stack Python application:

*   **Backend / ML Service**: Built with **FastAPI**. It exposes REST endpoints that utilize Machine Learning models (Scikit-Learn) and heuristic algorithms to provide intelligent insights.
*   **frontend / UI**: Built with **Reflex** (formerly Pynecone), a pure Python web framework. It provides a modern dashboard interaction.

---

## **3. Code Structure & File Analysis**

### **Root Directory**
*   **`main.py`**: The entry point for the **FastAPI ML Service**.
    *   **EligibilityPredictor**: A bespoke wrapper class that manages a **Random Forest Classifier**. It trains on beneficiary data (age, income, caste, etc.) to predict scheme eligibility. It includes fallback rule-based logic and model persistence (saving/loading using `joblib`).
    *   **SkillRecommender**: A logic-based recommender that matches beneficiary profiles (education, location) with a hardcoded database of skills (with demand scores, growth rates).
    *   **IncomeActivityRecommender**: Suggests small business ideas (e.g., Kirana Store, Mobile Repair) based on investment capacity and existing skills.
    *   **API Endpoints**:
        *   `POST /predict-eligibility`: Returns eligibility score, confidence, and detailed breakdown.
        *   `POST /recommend-skills`: Returns customized skill suggestions.
        *   `POST /recommend-income-activity`: Returns business ideas.
    *   **Startup Event**: Automatically trains a dummy model if a pre-trained one is not found, ensuring the API is testable immediately.

*   **`requirements.txt`**: Lists dependencies, notably `reflex`, `fastapi`, `scikit-learn`, `pandas`, `numpy`, and `joblib`.

### **`app/` Directory (Reflex Application)**
This folder contains the frontend logic.
*   **`app.py`**: The main application entry point. It sets up the app theme, imports pages, and defines the routing logic (`render_page`).
*   **`components/`**: Likely contains reusable UI widgets (Sidebars, Headers, Dialogs).
*   **`pages/`**: Contains the code for individual screens:
    *   `dashboard_page`: Main overview.
    *   `schemes_page`: Listing and details of government schemes.
    *   `training_page`: Skill development interface.
    *   `business_page`: Entrepreneurship/Business ideas.
    *   `chatbot_page`: AI assistant interface.
    *   `doc_scan_page`: Document scanning functionality.
*   **`states/`**: Manages the application state (likely using Reflex's reactive state engine), separating logic from the UI. `PMAJAYState` seems to be the central state class.

---

## **4. Key Functionalities & Tasks Performed**

### **A. Intelligent Decision Support (ML)**
*   **Eligibility Scoring**: Uses a trained ML model to determine the probability of a beneficiary qualifying for a scheme.
*   **Breakdown & Explainability**: Provides reasons for the score (e.g., "Income too high," "Meets category criteria").
*   **Market-Driven Recommendations**: dynamically suggests skills and businesses based on economic parameters like market demand, growth rate, and investment needs.

### **B. User Interaction (App)**
*   **Unified Dashboard**: acts as a single pane of glass for all beneficiary services.
*   **State Management**: seamless switching between different modules (Schemes, Training, Business) without page reloads.
*   **Helper Tools**: Includes specialized pages for scanning documents and chatting with an AI assistant.

---

## **5. Technology Stack**
*   **Language**: Python 3.x
*   **Web Frameworks**: FastAPI (Backend API), Reflex (Frontend/Full-stack)
*   **Machine Learning**: Scikit-Learn (RandomForestClassifier), Pandas, Numpy
*   **Data Serialization**: Joblib
*   **AI & OCR**: OpenAI GPT, Tesseract OCR, OpenCV
*   **Database**: PostgreSQL (recommended for production), SQLAlchemy ORM
*   **Utilities**: Pydantic, Python-dotenv, Requests

---

## **6. Data Flow & Workflow**

### **User Journey**
1. **Beneficiary Registration**: User profile is created with demographic and economic data
2. **Dashboard Access**: User views personalized overview of available opportunities
3. **Scheme Discovery**: Browse and filter government schemes based on eligibility
4. **Eligibility Check**: ML model predicts eligibility score with detailed breakdown
5. **Skill Assessment**: System recommends market-relevant skills
6. **Training Enrollment**: User enrolls in recommended training programs
7. **Business Planning**: Get suggestions for income-generating activities
8. **Product Listing**: List products from established businesses
9. **AI Assistance**: Get instant help via chatbot
10. **Document Processing**: Upload and extract text from certificates/forms

### **ML Prediction Workflow**
```
User Input (Beneficiary Profile + Scheme Criteria)
    ↓
Feature Engineering (Encode categorical, scale numerical)
    ↓
Model Prediction (Random Forest Classifier)
    ↓
Post-processing (Score breakdown, recommendations)
    ↓
API Response (Eligibility score, confidence, suggestions)
```

### **State Management Flow**
```
User Action (Click, Form Submit)
    ↓
Event Handler (Reflex State Method)
    ↓
State Update (Reactive State Change)
    ↓
UI Re-render (Automatic Component Update)
```

---

## **7. Database Schema (Conceptual)**

While the current implementation uses in-memory data, here's the recommended schema for production:

### **Beneficiaries Table**
- `id`: Primary Key
- `name`, `aadhaar`, `phone`, `email`
- `caste_category`, `income`, `education_level`
- `district`, `state`
- `registration_date`, `last_updated`

### **Schemes Table**
- `id`: Primary Key
- `scheme_name`, `category`, `department`
- `eligibility_criteria` (JSON)
- `benefits`, `deadline`
- `is_active`, `created_at`

### **Applications Table**
- `id`: Primary Key
- `beneficiary_id` (Foreign Key)
- `scheme_id` (Foreign Key)
- `application_date`, `status`
- `eligibility_score`, `documents`

### **Training Programs Table**
- `id`: Primary Key
- `program_name`, `provider`, `duration`
- `location`, `seats_available`
- `start_date`, `end_date`

### **Enrollments Table**
- `id`: Primary Key
- `beneficiary_id` (Foreign Key)
- `program_id` (Foreign Key)
- `enrollment_date`, `completion_status`

---

## **8. API Integration Points**

### **External APIs (Potential)**
- **Government Scheme Database**: Fetch real-time scheme data
- **Job Portal APIs**: Get market demand for skills
- **Payment Gateway**: Process application fees
- **SMS/Email Service**: Notifications for deadlines
- **Document Verification**: Aadhaar, PAN verification

### **Internal API Endpoints**
- `/predict-eligibility`: ML-based eligibility scoring
- `/recommend-skills`: Skill recommendation engine
- `/recommend-income-activity`: Business idea suggestions
- `/chatbot`: AI-powered Q&A (OpenAI integration)
- `/ocr`: Document text extraction (Tesseract)

---

## **9. Security Considerations**

### **Current Implementation**
- CORS enabled for development (needs restriction in production)
- No authentication/authorization (needs JWT/OAuth)
- Environment variables for sensitive data (.env)

### **Production Recommendations**
1. **Authentication**: Implement JWT-based auth
2. **Authorization**: Role-based access control (Admin, Beneficiary, Officer)
3. **Data Encryption**: Encrypt sensitive fields (Aadhaar, income)
4. **Rate Limiting**: Prevent API abuse
5. **Input Validation**: Sanitize all user inputs
6. **HTTPS**: Use SSL certificates
7. **Audit Logs**: Track all data access and modifications

---

## **10. Performance Optimization**

### **Current Bottlenecks**
- In-memory data storage (not scalable)
- Synchronous ML predictions (can be slow)
- No caching mechanism

### **Optimization Strategies**
1. **Database**: Use PostgreSQL with connection pooling
2. **Caching**: Redis for frequently accessed data
3. **Async Processing**: Background tasks for ML predictions
4. **CDN**: Serve static assets via CDN
5. **Model Optimization**: Use lighter models or model compression
6. **Pagination**: Implement for large datasets
7. **Lazy Loading**: Load components on demand

---

## **11. Testing Strategy**

### **Unit Tests** (To be implemented)
- Test individual ML model components
- Test state management functions
- Test API endpoint logic

### **Integration Tests**
- Test API endpoints with sample data
- Test database operations
- Test external API integrations

### **E2E Tests**
- Test complete user workflows
- Test UI interactions
- Test form submissions

### **Load Tests**
- Test API performance under load
- Test concurrent user handling
- Identify bottlenecks

---

## **12. Deployment Guide**

### **Development**
```bash
# Local development
uvicorn main:app --reload --port 8000
reflex run
```

### **Production Deployment**

**Option 1: Docker**
```dockerfile
# Dockerfile for FastAPI
FROM python:3.10-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

**Option 2: Cloud Platforms**
- **Render**: Deploy FastAPI and Reflex separately
- **Railway**: Single-click deployment
- **AWS**: EC2 + RDS + S3
- **Heroku**: Use Procfile for both services

**Option 3: VPS**
- Use Nginx as reverse proxy
- PM2 or systemd for process management
- PostgreSQL for database
- Redis for caching

---

## **13. Future Enhancements**

### **Phase 1: Core Features**
- ✅ ML-based eligibility prediction
- ✅ Skill recommendations
- ✅ Business idea suggestions
- ✅ Interactive dashboard
- ✅ AI chatbot
- ✅ Document scanner

### **Phase 2: Advanced Features** (Planned)
- 🔲 Real-time scheme updates from government APIs
- 🔲 Multi-language support (Hindi, regional languages)
- 🔲 Mobile app (React Native/Flutter)
- 🔲 SMS/WhatsApp notifications
- 🔲 Payment integration for fees
- 🔲 Document upload and verification
- 🔲 Video tutorials for schemes
- 🔲 Community forum for beneficiaries

### **Phase 3: Analytics & Reporting**
- 🔲 Admin dashboard with analytics
- 🔲 Scheme performance metrics
- 🔲 Beneficiary success tracking
- 🔲 ML model performance monitoring
- 🔲 Automated reporting for government officials

### **Phase 4: AI Enhancements**
- 🔲 Deep learning models for better predictions
- 🔲 NLP for document understanding
- 🔲 Recommendation system improvements
- 🔲 Fraud detection
- 🔲 Sentiment analysis on feedback

---

## **14. Contributing Guidelines**

### **Code Structure**
- Follow PEP 8 for Python code
- Use type hints for function parameters
- Write docstrings for all functions
- Keep components small and reusable

### **Git Workflow**
```bash
# Create feature branch
git checkout -b feature/new-feature

# Make changes and commit
git add .
git commit -m "Add: Description of changes"

# Push and create PR
git push origin feature/new-feature
```

### **Commit Message Convention**
- `Add:` New features
- `Fix:` Bug fixes
- `Update:` Modifications to existing features
- `Refactor:` Code restructuring
- `Docs:` Documentation changes

---

## **15. Troubleshooting & FAQ**

### **Q: Model accuracy is low**
**A**: Train with more real-world data. Current model uses dummy data.

### **Q: How to add new schemes?**
**A**: Edit `app/states/pmajay_state.py` → `fetch_all_data()` → `schemes` list

### **Q: Can I use a different ML model?**
**A**: Yes! Modify `EligibilityPredictor` class in `main.py`

### **Q: How to deploy to production?**
**A**: See Section 12 (Deployment Guide) above

### **Q: Is this production-ready?**
**A**: No, this is a prototype. Needs authentication, database, and security hardening.

---

## **16. License & Credits**

### **Open Source Libraries Used**
- **FastAPI**: Modern web framework
- **Reflex**: Full-stack Python framework
- **Scikit-learn**: Machine learning
- **OpenAI**: AI chatbot
- **Tesseract**: OCR engine

### **Purpose**
This project is designed for educational and social welfare purposes to demonstrate how technology can empower marginalized communities through better access to government schemes.

---

## **17. Contact & Support**

For questions, issues, or contributions:
- 📧 Create an issue on GitHub
- 📚 Read the documentation (README.md, QUICKSTART.md)
- 🧪 Test the API using `test_api.py`

---

**Project Status**: ✅ Prototype Complete | 🚧 Production Enhancements Planned

**Last Updated**: December 2025
